


import React from 'react';


import Resize from './Chat.jsx'
import  './App.css';
import FormExample from './FormExample.jsx';




const App = () => {

  return (
   <div className='container'> 
       <h1>Welcome to React

        {/*<Resize />*/}
        </h1>

        <FormExample />
   </div> 
 
  );
};

export default App;