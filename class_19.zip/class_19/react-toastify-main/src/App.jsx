import React from 'react'



import "./App.css"
import FormExample from './FormExample'


const App = () => {
  return (
    <div className='contain'>
      <h1>Welcome to React
      </h1>

   <FormExample />
    </div>
  )
}

export default App