


import React from 'react';

import ClickEvent from './ClickEvent.jsx'


import  './App.css';




const App = () => {

  return (
   <div > 
       <h1>Welcome to React

        <ClickEvent />
        </h1>
   </div> 
 
  );
};

export default App;