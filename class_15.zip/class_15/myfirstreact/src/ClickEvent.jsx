

import React from 'react'
import { useState } from 'react'


const ClickEvent = () => {

    //Lets perform the , auto incroment on a numnber by using 'click' event
    const [number , setNumber ] = useState(0)

    const increment = () => { //these increment function will adds 1 to number, so when we click on increment button, that click activity should call these function increment, for that we have to use 'onClick' attribute and assign that attribute to these function name which holds the addition activity.
        setNumber(number+1)
    }

    //Lets implement the decrement function
   /*
    const decrement = () => {  //these decrement function will subtracts 1 from number, so when we click on decrement button, that click activity should call these function decrement, for that we have to use 'onClick' attribute and assign that attribute to these function name which holds the subtraction activity.
       
        setNumber(number-1)
    }
        */


    //lets prevent the decrement function to proceed the decrementation until number value 0
     const decrement = () => {  //these decrement function will subtracts 1 from number, so when we click on decrement button, that click activity should call these function decrement, for that we have to use 'onClick' attribute and assign that attribute to these function name which holds the subtraction activity.
       if(number>1){
        setNumber(number-1)
       }
    }

    

    //Lets add the reset function,i.e when user clicks on reset button, it should display the number which is initial like 0, undo all the incrementation or decrementation happened on it.
    const reset = () => {
        setNumber(0)
    }

    return (
       // <div>ClickEvent</div>
       <div>
        <h1>{number}</h1>
       
          <button onClick = {increment} >Increment</button> {/*when we click on increment button, that click activity should call the above function increment, for that we have to use 'onClick' attribute and assign that attribute to these function name which holds the addition activity.*/}
        <br></br>
          <button onClick = {decrement} >Decrement</button> {/*when we click on decrement button, that click activity should call these function decrement, for that we have to use 'onClick' attribute and assign that attribute to these function name which holds the subtraction activity. */}
       <br></br>
          <button onDoubleClick={reset} >Reset</button>
       </div>
    )
}

export default ClickEvent