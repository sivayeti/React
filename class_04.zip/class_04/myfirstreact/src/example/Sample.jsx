
import React from 'react'
import TestComp from './TestComp'

//It is js code
const Mango = () => {  //As of now we created the components by using normal functions, now we will use arrow function to create component
      return(
        <h2 style={{ border: '2px solid green',margin: '25px'  }}>Mangoes are sweet</h2>
      )
}  //These component returns h2 tag content, and we have to place these component inside the <div> tag in Sample Content, which follow the rules for following parent component Sample i.e whatever the returned content should be in between <div></div>

const Grapes = () => {
    return(
        <h2 style={{ border: '2px solid orange', margin: '35px'  }}>Grapes are Good</h2>
    )
}

//It is jsx code 
function Sample() { 
    return (
        <div style={{ border: '2px solid blue', margin: '15px'  }}>Sample    
             <Mango />   {/*Inside the Sample Component , we place the Mango component,which like sample component contains Mango coponent, when Sample component exported and executed then Mango Component called automatically and executed.*/}
             <Grapes />
             <TestComp /> {/*//these component is created in another outside file TestComp.jsx , not created inside these file Sample.jsx */}
        </div>
       
    )
}

export default Sample
//Now we have to create another component inside these Sample() componnet to achieve Nested Component creation
//As of now we created the components by using normal functions, now we will use arrow function to create component

//In the file ,1st we have created a Sample() Component{which returns <div>Sample</div>} by using normal function
//In the same file we have created another component Mango(){which returns <h2></h2>} by arrow function
//Inside the Sample Component , we place the Mango component,which like sample component contains Mango coponent, when Sample component exported and executed then Mango Component called automatically and executed.


//Lets create another component Grapes, and place it in Sample Component.




//Note:
//Component can be responsible for returning or show the h1,h2,div,p,images,a link, any content content on screen, these content we displayed on the screen by using Components , because when we create group of components and each component displays respective content and then we can apply the styling on the components, and another advantage is we can make our interface portable based on screen device.
//When we displayed the content by using components, we can easily change the User interface based on the desktop, mobile(portable), we can achieve portability when we developed the interface by using components
