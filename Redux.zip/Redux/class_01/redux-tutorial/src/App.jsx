import { useState } from 'react'

import './App.css'
import NavBar from './projectFolder/NavBar'
import PostDisplay from './projectFolder/PostDisplay'

function App() {
  
  return (
   <>
   <NavBar />
   <PostDisplay />
   </>
  )
}

export default App
