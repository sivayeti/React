import React, { useState } from 'react';
//The input name,  to send to the reducer  from here, we have to use the Dispatch() hook
import { useDispatch } from 'react-redux';
import { addUsers } from './redux/userSlice';


const UserForm = () => {
    const [userName, setUserName]= useState('')

    
   const dispatch = useDispatch();

    const userNameHandler =(e)=>{
        setUserName(e.target.value)
        //console.log(userName)
    }

const submitHandler =(e)=>{
    e.preventDefault()
    console.log("This is username: ", userName);
    //WE WILL get the username from here.
    dispatch(addUsers(userName)) //we are passing the values from component to reducers and fire the reducers will be handles by dispatch() function.
   
    //After submit is done the form should clear ,for that
    setUserName("");
    
}

  return (
    <div >
        <form className='formSection' onSubmit={submitHandler}>
            <h4>User Name</h4>
            <div className="userInput">
                <input type="text" value={userName} onChange={userNameHandler}/>
                <button type='submit'>Submit</button>
            </div>
        </form>
    </div>
  )
}

export default UserForm






//for practicing
// import React, { useState } from 'react';

// const UserForm = () => {
//     const [userName, setUserName]= useState('')
//     const userNameHandler =(e)=>{
//         setUserName(e.target.value)
//         //console.log(userName)
//     }
// const submitHandler =(e)=>{
//     e.preventDefault()
//     console.log("This is username: ", userName);
   
// }

//   return (
//     <div >
//         <form className='formSection' onSubmit={submitHandler}>
//             <h4>User Name</h4>
//             <div className="userInput">
//                 <input type="text" value={userName} onChange={userNameHandler}/>
//                 <button type='submit'>Submit</button>
//             </div>
//         </form>
//     </div>
//   )
// }

// export default UserForm