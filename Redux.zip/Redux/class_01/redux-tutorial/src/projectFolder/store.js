import { configureStore } from '@reduxjs/toolkit'

import counterReducer from './redux/counterSlice'
//As we exported recucer from counterSlice, when we importing that reducer we can give any name to reducer and import, but we have to specify the correct path from where, we are importing the reducer
import userReducer from './redux/userSlice'

import commentReducer from './redux/commentSlice';



export const store = configureStore({
  reducer: { //In these reducer, we have to specify the feature name, from where we are importing the reducer, and that feature name,we have to assign the imported reducer
    counter: counterReducer, //Now inside the store, we have the updated state, in counter feature
    //We can use the updated state in counterReducer in counter feature, throught the application wherever we wants.
    
    newSubscriber: userReducer, //the updated state which is proccessed in reducer, that is stored in newSubscriber feature
    //from these newSubscriber state , we can access its values any where in application
    
    newComments: commentReducer
    //These newComments is a state now


    
   
  },

})

// // Infer the `RootState` and `AppDispatch` types from the store itself
// export type RootState = ReturnType<typeof store.getState>
// // Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}
// export type AppDispatch = typeof store.dispatch



