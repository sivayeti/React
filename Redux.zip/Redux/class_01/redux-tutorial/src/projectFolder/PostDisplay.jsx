import React, {useState} from 'react'
import NewUser from './NewUser';
import NewComments from './NewComments';
import UserForm from './UserForm';
import CommentForm from './CommentForm';

import { useDispatch } from 'react-redux';
import { increment } from './redux/counterSlice'; // we have to importthe reducer action, which we want to fire when particular button clicks, and use that action , here, whenever that particular button clicks, ensures that imported reducer action, will be fired.



const PostDisplay = () => {

    const [showUser, setShowUser] = useState(false);
    const [showComment, setShowComment] = useState(false)
    
    
    const dispatch = useDispatch(); //Import the useDispatch hook, and assign it to a variable here
    //In next step, when ever the like button clicks, our increment action in reducer should fire , that reducer process that increment action,
    //  for these we have to import the incremnt action in reducer in counterSlice feature here


    const likeHandler = ()=>{
        dispatch(increment()); //By using the dispatch hook assigned variable, we will fires the increment() or imported reducer function.
        //By using the dispatchers, we are passing the ‘state’ to ‘reducers’ actions or functions.
        //Here we are processing the state, by using the increment() function in recucer
       
        //from here we are passing the state to Reducer action increment() , by using the dispatch
        //The reducer will process the state, and stores the updated state, in store.js, 
        //from that store we can use the updatedstate wherever in application we want.
        
    } //These likeHandler, should activate when we onClick() on the Like button


    
    
    const userHandler =()=>{
      setShowUser(true)
    }
    const commentHandler =()=>{
      setShowComment(true)
    }
  

  return (
    <div className='postSection' >
    <div className="poster">
    <div className="postImage">
             <img src="assets/Kashmir.jpg" alt="" />
         </div>
         <div className="postButtons">
             <button onClick={userHandler}>Subscribe</button>
             <button onClick={commentHandler}>Comment</button>

             <button onClick={likeHandler}>Like</button>
             {/*When we click on the Like button, then likeHandler function will activates, and fires the increment function by using the dispatch hook */}
             {/*The returned value from reducers , we have to show in navbar, as we all know that  the updated state, in reducers, we will stored in store.js, so we have to import the store.js in navbar, and use the updated value from store.js and ensures to display in navbar beside the 'Like'*/}
         </div>
         <div className="userForm">
          {showUser && <UserForm />}
         {showComment && <CommentForm />}
         </div>
    </div>
         <div className="subSection">
             <NewUser />
             <NewComments />
         </div>
     </div>
  )
}

export default PostDisplay









//for practicing
// import React, {useState} from 'react'
// import NewUser from './NewUser';
// import NewComments from './NewComments';
// import UserForm from './UserForm';
// import CommentForm from './CommentForm';


// const PostDisplay = () => {

//     const [showUser, setShowUser] = useState(false);
//     const [showComment, setShowComment] = useState(false);


    
    
//     const userHandler =()=>{
//       setShowUser(true)
//     }
//     const commentHandler =()=>{
//       setShowComment(true)
//     }
  

//   return (
//     <div className='postSection' >
//     <div className="poster">
//     <div className="postImage">
//              <img src="assets/Kashmir.jpg" alt="" />
//          </div>
//          <div className="postButtons">
//              <button onClick={userHandler}>Subscribe</button>
//              <button onClick={commentHandler}>Comment</button>

//              <button >Like</button>
//                 </div>
//          <div className="userForm">
//           {showUser && <UserForm />}
//          {showComment && <CommentForm />}
//          </div>
//     </div>
//          <div className="subSection">
//              <NewUser />
//              <NewComments />
//          </div>
//      </div>
//   )
// }

// export default PostDisplay