import {createSlice} from  "@reduxjs/toolkit";

//for userSlice, we can assign these feature name, initial state, reducer actions , by using 'create-slice'

    
export const userSlice = createSlice({
    
    name: 'newSubscriber',
    
    initialState:{
        users:[]
    },
    
    reducers:{
        //Here we defined addUsers expression , by implementing arrow function, which can takes two arguments, state(initial state), action(function) which updates the initial state.

        addUsers: (state, action)=>{ //By using the action , we will update the states.
                  state.users.push(action.payload) //The values which we get from the action, those values are pushed to users list  in state.
        }
    }
})


//Lets destructure the actions in reducers
export const {addUsers} = userSlice.actions;
//reducers are destructured and assigned to   actions in userSlice, which we created for subscriber/user feature

export default userSlice.reducer; //the reducer from userSlice, will be exported here.


