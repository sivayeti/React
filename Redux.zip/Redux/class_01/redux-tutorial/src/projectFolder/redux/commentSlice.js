import { createSlice } from "@reduxjs/toolkit";


export const commentSlice = createSlice({

    name: 'newComments',
    initialState:{
        comments:[]
    },
    reducers:{
        addComments: (state, action) => {
             state.comments.push(action.payload);
        }
    }

})

export const {addComments} = commentSlice.actions;
//destructuring the reducers, and assign them as actions in commentSlice
//Now export the reducers
export default commentSlice.reducer;