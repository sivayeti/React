import { createSlice } from '@reduxjs/toolkit' //1st step in redux

export const counterSlice = createSlice( { // //1st step in redux, creating the slice for each feature

 name : 'counter', //For each feature(counter) we have to create the slice
                   //the slice which we created for feature(counter) we can have the name 'counter', by using the 'name' attribute

 //2nd steap in redux, Initializing  the initial state
 initialState:{
    value:0
 },
 
 //3rd step creating the reducers to process the initial state
 reducers:{ //reducers having the function or actions which are needed to process the initial state
    increment:(state) =>{ //These increment function is assigned to arrow function, that arrow function will take the state as parameter, which means initial state properties.

        state.value += 1
    }
 }

 //These reducers are processed by actions
})

export const {increment} = counterSlice.actions //we have destructered the reducers, and assigned actions to them

//4th step, export the reducer in slice which we created for respective feature
export default counterSlice.reducer //Here we exported the reducer  in counter 

//And in next step these reducer should be import in store.
