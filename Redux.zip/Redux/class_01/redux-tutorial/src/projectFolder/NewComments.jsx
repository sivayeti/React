import React from 'react'
import { useSelector } from 'react-redux'

const NewComments = () => {

  const newComment = useSelector((s) => s.newComments.comments)  
 //Now newComments has updated comments list

  return (
    <div className='commentSection'>
        Comments: 
        {newComment.map(
            (item, index)=>{
                return(
                    <div key={index}>
                        <ul>
                          {item}
                        </ul>
                        </div>
                )
            }
        )}
 
    </div>
  )
}

export default NewComments








//for practicing
// import React from 'react'


// const NewComments = () => {

  
//   return (
//     <div className='commentSection'>
//         Comments: 
        
 
//     </div>
//   )
// }

// export default NewComments





