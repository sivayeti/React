
import React from 'react'
import {useSelector } from 'react-redux'; //By using these useSelector() hook, we can use the updated states in store in these component.

const NavBar = () => {
    const updatedLikes = useSelector((state)=>state.counter.value) //In store, we can multiple features, in reducer, In the entire states, we want to access the updated state from particular feature.
    //Now updated likes , hold the updated value from counter feature in store

    const userCount = useSelector((state)=>state.newSubscriber.users)
    //Now userCount having the all updated users list

    const commentCount = useSelector((s)=>s.newComments.comments)
    return (
        <div className='navSection'>
            <div className="navTitle">
                Redux
            </div>
            <div className="navUser">
                Subscribers: {userCount.length}
            </div>
            <div className="navComments">
                Comments:  {commentCount.length}
            </div>
            <div className="navLikes">
                Likes: {updatedLikes}
            </div>

        </div>
    )
}

export default NavBar




//for practicing
// import React from 'react'

// const NavBar = () => {
   
//     return (
//         <div className='navSection'>
//             <div className="navTitle">
//                 Redux
//             </div>
//             <div className="navUser">
//                 Subscribers: 
//             </div>
//             <div className="navComments">
//                 Comments: 
//             </div>
//             <div className="navLikes">
//                 Likes: 
//             </div>

//         </div>
//     )
// }

// export default NavBar