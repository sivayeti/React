import React from 'react'
import { useSelector } from 'react-redux'

const NewUser = () => {

    const newUsers = useSelector((state)=> state.newSubscriber.users)
    //newUsers has updated state in it
    //It is a list, by using the map() function , we can access the each element in list


 
  return (
    <div className='userSection'>
        Subsribers:
        {newUsers.map((item, index) =>{
            return(
                <div>
                    <ul key={index}>
                         <li>{item}</li>
                    </ul>
                   

                    </div>
            )
        })}
    </div>
  )
}

export default NewUser



/* for practicing
import React from 'react'

const NewUser = () => {

  return (
    <div className='userSection'>
        Subsribers:
      
    </div>
  )
}

export default NewUser
*/