


import React from 'react'
import  './App.css';


function App() {
  return (
   <div className = "container"> {/*parent - element*/} {/*how we can identify the elements here, by using the Attributes like className,id we will give the name for each element*/}

     <p className = "para">This is Paragraph</p> {/* child element */}
   </div> //Now, here the name for these "div" is 'container'
   //by using the <div> tag name 'container' we can apply the styling from App.css
  )
}

export default App;