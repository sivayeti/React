

import React from 'react'

import {useState} from 'react' //syntax to import the useState from react.




const StateMgm = () => {

    //Syntax to use , useState Hook.
    const[city, setCity] = useState("Hyderabad") //these "Hyderabad" value is assigned to 'city' state or variable.
    //city is our state (means variable), 'setCity' is used to maipulate or change the city(state) variable value.

    //console.log(city)

    //In above we already defined a useState() Hook. under state, we passed 'city', "Hyderbad" is passed as value for 'city' state or variable.
    //Now for these we can write condition, by using that condition we can manage the state.
    //Here we can write a condition for the useState

    /*
   if(city === "Hyderabad"){
     setCity("Bangalore")
   }
     */

   if(city === "Goa"){
    setCity("Bangalore")
  }else{
    setCity("Delhi")
  }


    return (
       // <div>StateMgm</div>
       <div>
         {city} {/* dynamic values or variables which stores the values, outside the return statement or div tag, can be specified with in {curly braces} inside the return statement or div tag to display on screen */}
         <h1>I live in {city}</h1>
       </div>
    )
}

export default StateMgm