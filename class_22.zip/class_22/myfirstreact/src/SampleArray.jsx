

import React from 'react'

import {userData} from './data'

//Lets see how we can fetch the data from objects in array.


let fruits = ["apple", "mango"]

console.log(userData)

let players = [  //these array holds  object, now we have to display the object values, for that we have to use the map method.
    {
        cricket:"Dhoni",
        tennis:"Sania",
        chess:"Anand",
        hockey:"Dyan Chand"
    }
]


const SampleArray = () => {
    return (

        <div>
         
         {userData.map(
            (user) => {   
                //how map() method works is, it will iterate on each object, while each iteration, it will store each object on the variable 'user' which passed in the parenthesis of arrow function which is tajen as callback by map() method, in return statement arrow function, we can use the 'user' variable to display the data for respective iteration over all the array.
                return(
                    <div style={{border:"1px solid blue"}}>
                        <div>{user.username}</div> {/* //see , By default the variable which we passed to arrow function i.e user or item, it will iterate over the each array object, when we try to print particular object info,
Here we used ‘user’ variable to display the username,email,   ‘user’ variable iterate over the each array object and displays the 10 objects username,email , when we used the syntax ‘user.username’, ‘user.email’
*/}
                        <div>{user.email}</div>
                        {/*//Now the point is, we have fetched the usename, email by using syntax ‘variable.key_name’,  for normal data in objects,
//But how we can fetch the data from object type data in objects is: by using these syntax  
“user.nested_object_name.key_name_in_nested_object
“user.nested_object_name(i.e key_name for outer object).key_name_in_nested_object”
*/}                     <div>{user.address.street}</div> {/*Here user iterated all 10 objects, while accessing on each object, user variable uses the nested object name, to access the nesed object keys and to display the nested object key values */}
                        

                    </div>
                )
            }
         )
         }
            </div>

            
       //But Mostly we use Map() method to fetch the object values, because, we will get lot of objects from api, at that time if we want to specify the each object index and access the object values is complex, instead of these we will use Map() in which takes arrow function as callback, and the variable 'item' in arrow function, fetch the object values only based on key_names, 'item' variable don't need object index to fetch object values, it only needs key_name.
    )
}

export default SampleArray