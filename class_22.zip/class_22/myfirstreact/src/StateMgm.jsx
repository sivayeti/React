

import React from 'react'

import {useState, useEffect} from 'react' //syntax to import the useState from react.




const StateMgm = () => {

    //Syntax to use , useState Hook.
    const[city, setCity] = useState("Hyderabad") //these "Hyderabad" value is assigned to 'city' state or variable.
   

    useEffect(
      () => {
        if(city === "Hyderabad"){
          setCity("Bangalore")
        }else{
          setCity("Delhi")
        }
      },[] //[] --> Dependency which prevents the state to undergo loop.
    ) //Key point in useEffect is dependency, after call back function, if pass an empty array [],(these empty array is called dependency), these dependency prevents the state undergoing loop.
   
    /*
    if(city === "Goa"){
    setCity("Bangalore")
  }else{
    setCity("Delhi")
  }
*/

    return (
       // <div>StateMgm</div>
       <div>
         {city} {/* dynamic values or variables which stores the values, outside the return statement or div tag, can be specified with in {curly braces} inside the return statement or div tag to display on screen */}
         <h1>I live in {city}</h1>
       </div>
    )
}

export default StateMgm