
import React from 'react'

import Bangalore from './Bangalore'

const Hyderabad = ({gift}) => {
    return (
        <div>Hyderabad 
            <Bangalore gift = {gift} />
        </div>
    )
}

export default Hyderabad