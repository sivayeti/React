

import React from 'react'
import Hyderabad from './Hyderabad'

const Kolkata = ({gift}) => {
    return (
        <div>Kolkata
            <Hyderabad gift = {gift} />
        </div>
    )
}

export default Kolkata