
import React from 'react'
import Kolkata from './Kolkata'

import { useData } from '../context/ExampleContext'

//Here we will recieve the data from 'surprise' state which we defined in our context , and we have to destructure the state here.

const Mumbai = ({gift}) => {

    //We have to destrcutre the state which we recieve from the context, and assigned to useData() custome hook

    const {surprise} = useData()
    //Via the Surprise our data in context is reached to here Mumbai Component.
    //To display the data as output which we recived from context via surprise state.

    return (
        <div>Mumbai
          {/*  <h2>My NAME IS {surprise}</h2> */} {/*These is for single value 'Apple' in surprise state */}
          <h2>My NAME IS {surprise.captain}</h2>  {/*These is for surprise state has object , to access the 'captain' key value.*/}
        <Kolkata gift = {gift} />
        </div>
    )
}

export default Mumbai

//Now to use these same data 'Apple' in other component also same process, for example, i want to use these data 'Apple' in Bangalore Component