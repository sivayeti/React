


import React from 'react'
import { useData } from '../context/ExampleContext'   //1.import custom hook


const Bangalore = ({gift}) => {
    const {surprise} = useData()  //2.destructure our variable surprise, from useData, we can store the surpirse value in 'surprise' variable here.


    return (
        
       // <div> <h4>I am Bangalore, <span style={{color:"green"}}>{gift}</span>Recieved from Delhi</h4></div> 
       //<div> <h4>I am Bangalore, <span style={{color:"green"}}> {surprise} </span>Recieved from Delhi</h4> </div> //for single value 'Apple' in 'surprise' state.
       <div> <h4>I am Bangalore, <span style={{color:"green"}}> {surprise.game} </span>Recieved from Delhi</h4> </div>
    )
}

export default Bangalore

//In these way by using the useContext() concept, we can pass the data to multiple components.