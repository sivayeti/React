

import React from 'react'
import Mumbai from './Mumbai'


const Delhi = ({gift}) => {
    return(
        <div>
            Delhi
            <Mumbai gift = {gift} />
        </div>
    )
}

export default Delhi