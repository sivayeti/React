

import React from 'react'

import {Routes, Route } from 'react-router-dom'

import './App.css'
import NavBar from './Navbar'
import Delhi from './container/Delhi'
import { GiftProvider } from './context/ExampleContext'

const gift = "Apple"

const App = () => {
  return (
   
  // <div>App</div>
  <div>
    <h1>Sending Gift to Bangalore</h1>
    {/*<Delhi gift = {gift} /> */}
  
    {/*Here we have to provide the GiftProvider Component here */}
    {/*Inside the GiftProvider Component , we have to wrap the render components in main app */}
    <GiftProvider>
    {/*<Delhi gift = {gift} /> */}
    {/*Here we don't need props, from these Delhi component remaining all other components are redering i.e displaying on screen */ }

        <Delhi /> 
    </GiftProvider>
  
  </div>

  )
}

export default App