

import { createContext,useContext, useState } from "react";

//1.create context 
const GiftContext = createContext()  //we create the context and assigned to variable


//2.Prvider function
export const GiftProvider = ({children}) => { //these function takes parameter   'children' in props format

    //const [surprise, setSurprise] = useState("Apple") //defined a state or variable
    
    


    //Here, the case single value passed to multiple componnets, passed the 'Apple' value to useState() and assigned to 'surprise' state
//In case if we have multiple values, and we have to pass the multiple values to different components., then we have to create an object for that multiple values and passed to useState() and assigned to 'surprise' state.

    const [surprise, setSurprise] = useState(
        {
            game:"Cricket",
            captain:"Perry"
        }   //to get these new values which we are assigned to state surprise in Banagalore componenet is syntax:  state_name.key_name s(urprise.game)
    ) 
    
    //These GiftProvider function returns a component to us., we created the component in return  i.e <GiftContext.Provider/>


    return (
        //3.Custom Component
        <GiftContext.Provider value = {{surprise, setSurprise}}>  {/*syntax for custom component : context_name.Provider */}
                              {/* The value which we passed from the useState, now from these custom component , that value is paased to in the application as a data, then we have to create a custom hook}
                                {/*we have to pass the props  inside these custom Component , that props which we passed to the GiftProvider() function */}
           {children}
        </GiftContext.Provider>  //Now for these Custom Componenet we have to pass the Value, that value we will get from the useState which we defined above
        //Now these is the custom component
    )

}

//Here GiftProvider is one component



//4.custom Hook //1st import the useContext, which enables us to use the context which we created above
export const useData = () => useContext(GiftContext) //Now for these useContext(),  , the context GiftContext which we created is assigned to these useContext

//Now we have to export the both custom Hook(useData), Provider Function(GiftProvider) then only the data which we get from the context can be passed into the application 



//The data which we created in these context , that to use in other components  , can be done these by using the custom Hook.
//Eg:I want to use the data from these context to use in Mumbai component.  I have to import these custom Hook, in Mumbai Component.


//Here, the case single value passed to multiple componnets, passed the 'Apple' value to useState() and assigned to 'surprise' state
//In case if we have multiple values, and we have to pass the multiple values to different components., then we have to create an object for that multiple values and passed to useState() and assigned to 'surprise' state.

