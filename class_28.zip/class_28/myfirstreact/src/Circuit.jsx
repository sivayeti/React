

import React, { useState } from 'react'

const Circuit = () => {

    const [game, setGame] = useState(false) //for state or variable game , we have passed boolean value, true.


    const MyGame = () => {
        return (
            <div>
                <h2>I like Cricketer Smriti</h2>
            </div>
        )
    }  //These is one component , lets pass these component , instead of statement in logocal '&&' case

    return (
      //  <div>Circuit</div>
      <div>
       {/* {game && <div>I like cricket</div>} */}  {/* Here the output will be rendered based on the logical */}
                    {/*statements will be considered as true, these will get print on screen, when 'game' state is also 'true' otherwise These statement will not print on screen , because, '&&' logical and operator gives output as false , even one statement is false, these leads to prevent the display of statment on screen */}
       
       {game && <MyGame/>}  
               {/*Here Component & statements will be treated as true, but to render these components or statments on screen , is based on the other condition  due to logical '&&' AND, if other condition true, the component or statments will render on screen, if other condition false , then coponents or statements will not render on screen */}
     
      </div>
    )
}

export default Circuit