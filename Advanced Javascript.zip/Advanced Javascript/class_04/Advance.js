//Rest Operator

//while declaring  the function, we have to use Rest operator


//Befor RestOperator(...)
/*
function sampleRest(name, myCollection) {
 let exampleValue = 0;

 for(let i in myCollection){
    exampleValue += myCollection[i];
 }
  document.getElementById('output').innerHTML = exampleValue; //exampleValue = 0
}

*/

//After RestOperator(...)
function sampleRest(name, ...myCollection) { //(...) restOperator add our collections and then returns output
    //first ,we will see how (...) group of parameters among string & numbers, name argument stores , first string value "Kalyan", then ...myCollections  argument inouts the (10,20,30,40,"Marks"), then based on our logic (...) enables to add the 10,20,30,40 and at last concat the "Marks" to our output
    let exampleValue = 0;
   
    for(let i in myCollection){
       exampleValue += myCollection[i];
    }
    // document.getElementById('output').innerHTML = exampleValue; //exampleValue = 100
    document.getElementById('output').innerHTML = name;  //name = Kalyan
    document.getElementById('output').innerHTML += exampleValue;  //exampleValue = 100Marks
}


sampleRest("Kalyan", 10, 20, 30, 40,"Marks")