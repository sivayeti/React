//Asynchronous



//Synchronous - one by one code execution flow
/*
console.log("First Code")
console.log("Second Code")
console.log("Third Code")
console.log("Fourth Code")
console.log("Fifth Code")
*/


//Asynchronous - code will be executed, if any code has delay then another code will not wait for that and proceeds with execution.

console.log("First Code")
console.log("Second Code")
setTimeout(
   () => {
      console.log("Third Code")
   },3000
)

console.log("Fourth Code")
console.log("Fifth Code")


/*
console.log("First Code")
console.log("Second Code")
log("Third code") //Now these error will prevents the execution of code4,code5
// setTimeout(
//    () => {
//       console.log("Third Code")
//    },3000
// )

console.log("Fourth Code")
console.log("Fifth Code")
*/