//Lets implement the promises


/*
const Register = () => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log("Please Register");
            resolve("Successfull") //resolve holds success return by the code
        //if Promise is resolved, and that parameer in resolve() method is returned, to .then() function, because when promise becomes succesfull then promise calls .then() method automatically by passing resolve("paramaeter") method parameter.
        },3000)
    }
)
}

//when we are returning a promise  in function, that promise provides .then(), then() is called by promise when the code is success
Register().then((data) => {console.log(data)} )  
       //'data' is variable here.

       */








const Register = () => {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                console.log("Please Register");
                resolve("Successfull") //resolve holds success return by the code
            //if Promise is resolved, and that parameer in resolve() method is returned, to .then() function, because when promise becomes succesfull then promise calls .then() method automatically by passing resolve("paramaeter") method parameter.
              // reject("Regestration Failed")
        },3000)
        }
    )
    }
   
    
const Login = () => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            console.log("Please Login");
            resolve()
        },1000)
    })
}


//when we are returning a promise  in function, that promise provides .then(), then() is called by promise when the code is success
//Register().then((data) => {console.log(data)} )  
           //'data' is variable here.
//Login()




//even after implementing two functions with promises we dn’t find any change the flow is based on least time delay i.e Login,Register.
//But we want Register,Login irrespective of least time delay, obeys code flow, for that we call the Login() in inside the .then() which was provided by promises.

//Here Login is function expression, variabe for function, so we have to pass 'Login' in .then()
//These way of using Promises/call backs to achievie blockig of code or obeys the code flow, then it executes based on the codes flow, and also it obeys the time delay for each code


//Register().then(Login)

const Thankyou = () => {
    return new Promise( (resolve,reject) => {
       
    setTimeout(() => {
        console.log("Thank You & Wewlcome")
    },1000)

    }
)
}


Register().then(Login).then(Thankyou) //these is called method chaining ".then().then()"

//It is far better than callback using in asynchronous to ensure code flow, because we are using 1st code function as 2nd function code as callback, then inside these 2nd function code, 3 code function as call back, which may difficult to find out if any error rises,
//But here we are developing each function promises seperately and we are executing with method chaining one after other with simple syntax Register().then().then()



//Register().then(Login).then(Thankyou).catch((err) => console.log(err))