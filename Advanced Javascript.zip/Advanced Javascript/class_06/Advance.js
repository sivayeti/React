//Destructuring

/*
const sampleNumbers = [1, 2, 3, 4, 5, 6, 7, 8, "Mahesh"]
   //index values = // 0, 1, 2, 3, 4, 5, 6, 7, 8

document.getElementById('output').innerHTML += sampleNumbers[8];

//To simplify these , we use Destructuring
//In destructuring, it enables us to access the values with names defined by us, instead of accessing array_name[index_value]].

const [one, two, three, apple, cinema, books, sports, eight, nine] = sampleNumbers; //It's like, we will create the name for each value, and by using that names we can access the array values

document.getElementById('output1').innerHTML +=  cinema + "<br>";
document.getElementById('output1').innerHTML +=  "My name is :" + nine;
*/



//we can also apply the destructuring on objects.
const FullName = {
   fName: "Suman",
   lName: "Kalyan"
}

const {fName,lName} = FullName   //These is called Destructuring

document.getElementById('output').innerHTML += fName + lName;