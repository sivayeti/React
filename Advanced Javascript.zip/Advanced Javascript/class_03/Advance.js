//Loops


//for..of --> [Arrays]
//for..in --> [objects]


const myValues = [1,2,3,4]
const students = ["Mahesh","Suresh","Prakash"]

//on each element in list [1,2,3,4] which is stored in 'myValues' variable , we have to apply a callback function on each element of myValues list.
/*
myValues.forEach( function(a){
    //each element in list is passed to and stored in 'a' in respective iteration
    //document.getElementById('output').innerHTML += a + "<br>";
    document.getElementById('output').innerHTML += a*2 + "<br>";  //lets multiply the each element by 2. 
}
   
)
*/


//As of now we have used these "forEach()" loop to apply function in each element in list.
//we can simplify these loop by using "for..of()" loop
//for..of  //syntax : for( const/let/var variable of array_name) { statement }
for(const a of myValues){
    //document.getElementById('output').innerHTML += a;
    document.getElementById('output').innerHTML += a * 5 + "<br>";
}
//difference b/w the  for..of() & forEach() on arrays
//forEach() , when we apply these loop on list, then we have to use Callback function to print or perform operations on list elements
//for..of , when we apply these loop on list,then no need to use Callback function , we can directly the statements to print or perform operations
for(const a of students){
    document.getElementById('output').innerHTML += a + "<hr>";
   

    //DOM
    /*
    const p = document.createElement('p'); //we are creating the html tag from js only
    p.textContent = a ; // we are adding thml tag content from here
    output.appendChild(p); //we are adding the tag with content to html from here

    //output.appendChild(p); // ❌ This adds inside the output container

    document.body.appendChild(p); // ✅ Appends directly to the page body

    //Add hr tag
    const hr = document.createElement('hr'); // add <hr>
    document.body.appendChild(hr);
    */
}



//Like these way we will use the "for..of" loop on Arrays








//for..in --> objects

 const cities = {
    one: "Hyderabad",
    two: "Delhi",
    three: "Bangalore",
    four: "Chennai"
    
 }


 //for..in

 for(let x in cities){  //these 'x' variabe will traverse over the each Key.
        //document.getElementById('output1').innerHTML += x + "<br>";
        //if we want to print the values, then we use the syntax : object_name[key]
        document.getElementById('output1').innerHTML += cities[x] + "<hr>";
 }