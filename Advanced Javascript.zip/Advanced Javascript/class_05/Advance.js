//Rest Operator

//while declaring  the function, we have to use Rest operator


//Befor RestOperator(...)
/*
function sampleRest(name, myCollection) {
 let exampleValue = 0;

 for(let i in myCollection){
    exampleValue += myCollection[i];
 }
  document.getElementById('output').innerHTML = exampleValue; //exampleValue = 0
}

*/


/*
//After RestOperator(...)
function sampleRest(name, ...myCollection) { //(...) restOperator add our collections and then returns output
    //first ,we will see how (...) group of parameters among string & numbers, name argument stores , first string value "Kalyan", then ...myCollections  argument inouts the (10,20,30,40,"Marks"), then based on our logic (...) enables to add the 10,20,30,40 and at last concat the "Marks" to our output
    let exampleValue = 0;
   
    for(let i in myCollection){
       exampleValue += myCollection[i];
    }
    // document.getElementById('output').innerHTML = exampleValue; //exampleValue = 100
    document.getElementById('output').innerHTML = name;  //name = Kalyan
    document.getElementById('output').innerHTML += exampleValue;  //exampleValue = 100Marks
}


sampleRest("Kalyan", 10, 20, 30, 40,"Marks")
*/





//Spread Operator
const games = ["cricket","football","Tennis"]
const players = ["Dhoni","Richard","Pace"]
const coach = ["Amith","sumith"]
//document.getElementById('output').innerHTML += games;

const group = [...games , ...players, ...coach] //by Using Spread Operator(...), here we are combining the two arrays values into single array values.

document.getElementById('output').innerHTML += group;


//these spread operator not only on arrays, it can works on objects{dictionary} too.
const FirstName = {
   fName : "Suman"
}

const LastName = {
   lname : "Kalyan"
}

const fullName = {...FirstName,  ...LastName} // while combining object values into a single object values , we have to create new object with {curly braces} inside that only we need to combine by using spread operator.
console.log(fullName);
document.getElementById('output1').innerHTML += fullName.fName + fullName.lname;