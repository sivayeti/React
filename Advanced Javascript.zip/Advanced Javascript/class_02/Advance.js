
//Arrow Functions

//It simplifies the function writing process in javascript


//Regular function
function apple() { //creating function with name.
    document.getElementById('output').innerHTML += `I like apples <br>`;
    
}

apple()

//function expression

const mango  = function() { //anonymous function, after creating it we can assign to any variable or anywhere we can use it.
      document.getElementById('output1').innerHTML += `Mangoes are sweet <br>`;
}

mango()



//Let's see how the above functions are implemented in arrow functions
//const grapes = () => {document.getElementById('output1').innerHTML += `I like grape juice` }
//const grapes = () => document.getElementById('output1').innerHTML += `I like salad`   //for one statement we don't need the {curly braces} too.
//grapes()


//Lets see the arrow function with parameters
const grapes = (a,b) => {document.getElementById('output1').innerHTML += a+b}
grapes(10,20)