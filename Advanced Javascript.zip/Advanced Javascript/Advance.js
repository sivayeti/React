
var Example = "Cricket";

//document.write("I like Playing: " + Example)
document.getElementById("output").textContent = "I like Playing: " + Example; //normat method, without template strings


//Lets print the above thing with "Template Strings"
document.getElementById("output").innerHTML = `I like paying ${Example} <br><br> <h1> Happy to see you`;  //with template strings
//innerHTML can treats text,tags seperately, but .textContent treats text,tags as text only.

document.getElementById("output").innerHTML += `I like paying ${Example}`; //= overwrite, += concates to existed

console.log(`I like paying ${Example} <br>`);
/*
Property	Treats as...	Renders HTML?
textContent	Plain text	❌ No
innerHTML	HTML content	✅ Yes
*/