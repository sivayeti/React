//Asynchronous



//Synchronous - one by one code execution flow
/*
console.log("First Code")
console.log("Second Code")
console.log("Third Code")
console.log("Fourth Code")
console.log("Fifth Code")
*/


//Asynchronous - code will be executed, if any code has delay then another code will not wait for that and proceeds with execution.

/*
console.log("First Code")
console.log("Second Code")
setTimeout(
   () => {
      console.log("Third Code")
   },3000
)

console.log("Fourth Code")
console.log("Fifth Code")
*/


/*
console.log("First Code")
console.log("Second Code")
log("Third code") //Now these error will prevents the execution of code4,code5
// setTimeout(
//    () => {
//       console.log("Third Code")
//    },3000
// )

console.log("Fourth Code")
console.log("Fifth Code")
*/





//Lets see about the advance concept of Asynchronous
//how we implement the asynchronous in real time is about higher order functions 

// Welcome
// Register
// Login 
// Thankyou



/*
console.log("Welcome");

const Register = () => {
   setTimeout(
      () => {
         console.log("Please Register");
      },5000
   )
}



const Login = () => {
   setTimeout(
      () => {
         console.log("Please Login");
      },3000
   )
}



const Thankyou = () => {
   setTimeout(
      () => {
         console.log("Thank You");
      },1000
   )
}


Register()
Login()
Thankyou()

*/


console.log("Welcome");

const Register = (apple) => {  //that function(){} as parameter with in  the variable naming 'apple()
   setTimeout(
      () => {
         console.log("Please Register");
         apple() //the function which is passed as paramtere is again called here, i.e called 'Higher Order Function'.
      
      },5000
   )
}



const Login = (mango) => { //mango stores argument function function() { Thankyou() }
   setTimeout(
      () => {
         console.log("Please Login");
         mango()
      },3000
   )
}



const Thankyou = () => {
   setTimeout(
      () => {
         console.log("Thank You");
      },1000
   )
}


/*
Register(function(){ //these funtion as passe as argument here and
   //console.log("I like Apples")
   Login()
})
*/

//Login()
//Thankyou()

//The function which we passed as argument, if we call that function again in the body is called ‘Higher Order Function’.


//what we want here is that Login() is executing here, it should be execute after Register(), but due to time delay being considered in Asnchronous, Login() is executing before Register().
//So , we can achieve these by using 'Higher Order Functions'.i.e , we can use the Login() function inside the function(){} which is passed as argument to Register(), then it ensures that function(){ Login() } assed as parameter 'apple' to Register() and again called inside the Register() function body, so when Register function completes executing inside its code, then only it activates the apple() function which has function() { Login() }, Here we can achieve that after Register function  only Login() function will be activated, even Login() has less time delay when compared to Register() function by usinh 'Higher Order Function' concept.



//we have done , that after executing Register(), Login() executed irrespective of time delays considered in Javascript.
//Now we have to execute same that Thankyou() should execute after login.(same way as we executed the Login() after Register(), i.e we implanted higher order function in a way that Login() function is passed as argument to Register(), and again called inside the Register() function which enables that after Register() function time delay Register() function body start executing, then Login() Function inside Register() starts executing, which makes Login() execution after Register()).
//So to execute Thankyou() after the Login(), then  we have to pass Thankyou as argument to Login() function, and define Thankyou() parameter in Login() function , and call the function Thankyou() inside the Login() function which is passed as parameter to Login() function. 
//By following concept of ‘Higher Order Functions’.
//It ensures the execution of Thanyou() function after Login() function, even Thankyou() has less Time deay when compared to Login() function.

Register(function(){ //these funtion as passe as argument here and
   //console.log("I like Apples")
   Login(function(){
      Thankyou()
   }
)
})

//Login()
//Thankyou()


//Asynchronous is used to execute the codes which don’t need flow which should execute based on time delay they have, and ensures one code should not have to wait other codes scenario, in any real time situations, But in entire ansynchronous code run time environment if we need any codes execution based on flow instead of Time delays execution, we can use ‘Higher Order Function’ concept in  Asynchronous runtime  to achieve code flow based on our needs.

//we also implented here callBack Hell() concept means in one function we call other function,in the other function we call another function is called call Back hell().  //Register (    Login(  Thanyou()  )      )

//To follow the code follow in Asynchronous we can use 'Higher Order Function', for small applications, But for large applications which have unlimited response & request in asynchornous run time continously at that time using these callBackHell(), callBack(){passing one function as argument to other function} is becomes complex, because in runtime if we got any any error, it is difficult to find out the error in callback() functions code. So to resolve these issues we will use the concept 'Promises'
//for small applications we can use the 'Higher Order function' to obey the order execution, but for large applications, it is not good to use, because if we got any error in runtime , it becomes difficy=ult to find out error callBack() functions code, to overcome these we use 'Promises', while developing for large applications, which may have unlimited reponse & request.