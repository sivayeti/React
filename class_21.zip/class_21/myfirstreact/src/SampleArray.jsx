

import React from 'react'


//Lets see how we can fetch the data from objects in array.


let fruits = ["apple", "mango"]


let players = [  //these array holds  object, now we have to display the object values, for that we have to use the map method.
    {
        cricket:"Dhoni",
        tennis:"Sania",
        chess:"Anand",
        hockey:"Dyan Chand"
    }
]


const SampleArray = () => {
    return (

        <div>
          {players.map(
             (item) => {
             return(   //we have to return the values with in div tag, even in call back function here.
                <div>
                   <h2>My Fav Cricketer {item.cricket} </h2>
                   <h2>My Fav Player in Tennis {item.hockey}</h2>
                   <h2>My Fav Player in chess {item.chess}</h2>
                   <h2>My Fav Player in hockey {item.hockey}</h2>

                    </div>
             )
          }

          )
          
          }  {/*map() function takes another function as callback in it, lets take call back function as array function, inside the array function we can take a 'variable', by using that variable, we can access the value for repsective key, with syntax :variable.key(gives value for that key) */}
               {/*Here 'item' variable travels on key , and give the value of that key*/}
               {/*Here we applied the map() method on players array, here map() takes a array function as callback, array function has a variable in parenthesis(item), by using that variable we can access the object values , by using the syntax : item.key_name(gives that key value) */}
          
          


          {/*Even with out using Map also , we can fetch the object values */}
             {players[0].chess} <br/> {/*our players array has only one object so its index is 0, so first we have to access the object, then to retrieve the object value syntax: array_name[object_index].key_name(gives that key value) */}
             {players[0].hockey} <br />
             {players[0].cricket} <br />
            </div>

            
       //But Mostly we use Map() method to fetch the object values, because, we will get lot of objects from api, at that time if we want to specify the each object index and access the object values is complex, instead of these we will use Map() in which takes arrow function as callback, and the variable 'item' in arrow function, fetch the object values only based on key_names, 'item' variable don't need object index to fetch object values, it only needs key_name.
    )
}

export default SampleArray