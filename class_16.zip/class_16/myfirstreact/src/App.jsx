


import React from 'react';


import Resize from './Chat.jsx'
import  './App.css';




const App = () => {

  return (
   <div className='container'> 
       <h1>Welcome to React

        <Resize />
        </h1>
   </div> 
 
  );
};

export default App;