import React, {useState, useEffect } from 'react';

const Resize = () => {
    
    const [screenSize, setScreenSize] = useState( { width: window.innerWidth, height: window.innerHeight,});

 //These Resize() functional component initiates the state variable screenSize, and passes current window width & height values by using useState()
//Let's render these Resize() component in our main component APP to display on screen

    const updateScreenSize = () => {
          setScreenSize( { width: window.innerWidth, height: window.innerHeight, });  //these values are updated according to the screen width
         };



    useEffect(  //the purpose of useEffect here is, when the state or variable is changed , then looping will happens at that time, to prevent that looping we will use the useEffect()
       () => {
         window.addEventListener('resize', updateScreenSize);  //Inside these  useEffect(), we applied a method 'addEventListener() by adding a event 'resize'(1st parameter) i.e we added the 'resize' event to our window object, so whenever that 'reesize' event fires then 2nd parameter whch we passes 'updateScreenSize()' function will activates. 

         return () => {
             window.removeEventListener('resize', updateScreenSize); //To the same event 'resize' we are using 'removeEventListener', and calls the function
             //These removeEventListener makes remove the above EventListener which is added to our object
         };
        },[] //these empty arrow means dependency , which prevents the state undergoing loop when we use setState or setScreenSize() multiple times in our jsx file.
       );
       
 //First lets understand about these Event Listeners, from chatgpt clearly then we can understand these code


       return (
        <div>
            <h1> Screen Size Example</h1>
            <p>Resize the window to see the screen size: </p>
            <p style={{color:"Red"}}>Width: {screenSize.width}px</p>
            <p style={{color:"Red"}}>Height: {screenSize.height}px</p>
        </div>
       );
};

export default Resize;