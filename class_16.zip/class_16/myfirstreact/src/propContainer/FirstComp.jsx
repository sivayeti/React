


import React from 'react'

const FirstComp = () => {   //the variable ‘props’ which we specified in (parenthesis) , can store n no.of properties send by Parent App to the child component, to access particular property we can specify ‘props.property_name’ eg: props.name;
 
    return (
      <div>
        <h2>I AM First Component</h2>
      </div>
    )
}

export default FirstComp