
import React from 'react'

const ThirdComp = (props) => {
    return (
        //<div>ThirdComp</div>
        <div>{props.name}</div>
    )
}

export default ThirdComp;