

import React from 'react'


//spread opeartor on Arrays
/*
const one = ["apple","Mango"]
const two = ["grapes","orange"]
const three = ["pineapple","banana"]
//we can merge all these 3 arrays into single array by using (...) spread operator, syntac to use (...) spread to merge is: [...array1_name, ...array2_name, ...array3_name] these returns a single array by merging all the three array values.


const fruits = [...one, ...two, ...three]

console.log(fruits)
*/


//spread operator on Object
const obj1 = {a:1, b:2}
const obj2 = {c:3, d:4}

const total = {...obj1 , ...obj2}

console.log(total)

const Spread = () => {
    return (
        <div>Spread Operator </div>
    )
}

export default Spread