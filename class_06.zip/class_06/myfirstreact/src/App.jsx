


import React from 'react'


let a = "Mangoes"  //from apis we will get the data, and we will store the data in variables here, and we can use the variables in our code or components to display on screen dynamically.
let b = "bananas"


function App() {
  return (
    /*
    <div>
      Javascript XML
    </div>
    */

    /*

   <section>
     <h1>Javascript XML</h1>
     <h3>I am Siva</h3>
   </section>
   */

   <section>
   {/*Let see how dynamically values can be shown in jsx */ }

         <h1>I Like {a}, {b}</h1>  {/*In these way we will pass the values dynamically to jsx file codes or components*/}
   </section>
  )
}

export default App;