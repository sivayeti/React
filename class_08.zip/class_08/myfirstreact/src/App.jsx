


import React from 'react'
import  './App.css';


function App() {
  return (
   <div className = "container"> {/*parent - element*/} {/*how we can identify the elements here, by using the Attributes like className,id we will give the name for each element*/}

     <p className = "para">This is Paragraph</p> {/* child element */}
     

     <img src="https://cdn.pixabay.com/photo/2024/07/24/15/55/ai-generated-8918723_1280.png" />
  
  
    <img className="SivaPicture" src="PictureBox/Siva.jfif" alt="Lord Mahadev" /> {/* in case our specified is not loaded properly  instead of our image, alt attribute text will be displayed on screen*/}
    {/*//We already seen that we can name the <div>,<p> tags,by using className attribute, by using that names we apply the styling on it.
       //In the same way we can also name the each image tag by using className attribute.
     */}
   </div> //Now, here the name for these "div" is 'container'
   //by using the <div> tag name 'container' we can apply the styling from App.css

  
  )
}

export default App;