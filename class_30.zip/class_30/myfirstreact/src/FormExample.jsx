

import React from 'react'
import { useState } from 'react'

const FormExample = () => {

    const [userName, setUserName] = useState("") //we have passed a empty string to 'userName' variable or state

    const [newUserDetails, setNewUserDetails] = useState() //just defined but not assigned anything state or variable holding empty string

    const getUserName = (event) => {  //these function is used to store the typing value and assign to a variable or update variable while typing.
            //  event.target.value
          console.log(event.target.value)
          setUserName(event.target.value)
    }


    /*
    const userDetails = () => { //these function is used to store the typed value
        setNewUserDetails(userName) //these was stored in 'newUserDetails'  variable, these function activates only when submit button is clicked
    }
        */


    const userDetails = (e) => { //these function is used to store the typed value
        e.preventDefault() 
        //so, when we entered the data in form, and submitted, then onSubmit()  activates these userDetails() function, if activated function has these ‘preventDefault()’ in-built function prevents automatic refreshing, while or after these function execution.
        //Normally, when onSubmit in form activates in function, it reloads the function to its initial state, instead of these , if we use the ‘preventDefault()’ inside the activated function, avoids reloading

        setNewUserDetails(userName) //these was stored in 'newUserDetails'  variable, these function activates only when submit button is clicked
    }

    return (
     //   <div>FormExample</div>
     <section className='formSection'>
        {/* <h1>Hello, {userName}</h1> */}
         <h1>Hello, {newUserDetails}</h1>
        <div className='inputDiv' >
            {/*<h1>Hello {userName}</h1> */}
            {/*
            <input type="text" placeholder='Entry your Name' onChange={getUserName} />
            <br />
            <button className='submitBtn' onClick={userDetails}>Submit</button>
            */}
            <form onSubmit = {userDetails}>
            <input type="text" placeholder='Entry your Name' onChange={getUserName} />
            <br />
            <button className='submitBtn' type='submit'>Submit</button>
            </form>

        </div>
     </section>
    )
}

export default FormExample