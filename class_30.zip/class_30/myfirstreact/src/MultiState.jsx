

import React,{useReducer, useEffect} from 'react'

//1.first we have to define the types, means the actions which we are performing

//1st type
const FETCH_INIT = "FETCH_INIT"
//2nd type
const FETCH_START = "FETCH_START"
//3rd type
const FETCH_ERROR = "FETCH_ERROR"

//2.initial state
//And also i am here one initial state, i.e starting point define here
const initialState = {
    loading: true,
    data: null, //initially we don't the which data will return
    error:null, //And also we don't know which data we will get for the error, initially. 
} 
//As of now we defined the types and initial state

//4.define the function which is passed as parameter to useReducer Hook
//4.Reducer Function
const dataReducer = (state, action) => { //these dataReducer takes the under the  parameters as state, action, then inside the function we can manage the states.
    //Inside these arrow function we will manage the multiple states at a time.

    switch (action.type) {
        case FETCH_INIT: //the value which we passed to these case , is compared with action.type in switch(action.type) , if true, then returns the value under these case.
            //return {...state, } //By using the spread operator, we have updated the state value and passed here
           return {...state, loading:true, error:null} //In first state , we can give loading as true, and error as null, because we don;t what data we will get for error, in first state.
        
           case FETCH_START: //if these type is true, when compared with action.type, then we will get another object , which is specified under these case with in return statement
              return {...state, loading:false, data:action.payload }  //here loading becomes false, because ,already FETCH_START is started , so we will get the response from api, so we canmake the loading as 'false' ,
              // next data also returned here via 'action' we will pass the data to 'data' here i.e data: action.variable_name //whatever the thing coming from 'data' through action we are storing in varible_name (payload)

                  //  {...state} these means updated state, we are passing here 
            case FETCH_ERROR: //these alsor returns a object
            return {...state, loading:false, error:action.payload} 
                                          //whatever the error, we got we will store in 'error' by using '.payload'
       

         default:
            return state; //Default I am returning current state here.


            //so here, conditional via switch case statements we have defined the function , and updated the  states.
            //In next step we have to call the API, for that we will create a function, inside the function we will use Fetch() method to call API
        }
}

//3.useReducer() Hook define
//In next level , inside our component we have to define the useRedcucer
const MultiState = () => {
    //syntax for useReducer: useReducer(function_as_paramater, initial_state_as_parameter_which_is_object_we_defined_above)
    // these useReducer will return a state, & dispatch function
    //const [state, dispatch] = useReducer(function_as_paramater, initial_state_as_parameter_which_is_object_we_defined_above)
    const [state,dispatch] = useReducer(dataReducer, initialState)
    //In next step we have to define the function which we passed as parameter to useReducer Hook
    
    
    /*
    
    //5.API call
    const dataHandler =async () =>{ //we have to make these function as asynchronous because, we don't how much time it will take to fetch the data from api, so to use 'await' keyword inside the function we have to make these function as 'asynchronous' by using 'async' keyword, 'await' keyword ensure delaye the other codes, unitil the current codes executes.
        const response = await fetch("https://jsonplaceholder.typicode.com/users")

        const newData = await response.json() //response has recieved data from api, and here we converted the recieved data in to JSON format.

        //In next step . we have to define the actions inside these function, which we want to perform, these actions are the, In usereducer() hook,via  the function 'dataReducer' whcih we defined types from that types we will get the states .
        //So inside these function the 'dispatch' method return in useReducer() Hook
        //so by using the dispatch , we define the type , that state we will get output 


    
        
    }

    

    */

    /*
   //5.API call
   const dataHandler =async () =>{ //we have to make these function as asynchronous because, we don't how much time it will take to fetch the data from api, so to use 'await' keyword inside the function we have to make these function as 'asynchronous' by using 'async' keyword, 'await' keyword ensure delaye the other codes, unitil the current codes executes.
    

    
    //6.Dispatch Method
    //first i want to show the  loading , the loading when i want to show is, when the API is called , until the response get , these loading type is activated
     dispatch({type:FETCH_INIT})
    
    
    
    const response = await fetch("https://jsonplaceholder.typicode.com/users")

    

    const newData = await response.json() //response has recieved data from api, and here we converted the recieved data in to JSON format.

   //if the api response is success, then we defined the type : FETCH_START
   dispatch({type:FETCH_START, payload: newData}) //now in these payload variable, the data which we recieved from response is stored, 

   //now to show error case, we have to use try-catch, block
   //7.Error Handling 



    
}
   

*/
 //5.API call
 const dataHandler =async () =>{ //we have to make these function as asynchronous because, we don't how much time it will take to fetch the data from api, so to use 'await' keyword inside the function we have to make these function as 'asynchronous' by using 'async' keyword, 'await' keyword ensure delaye the other codes, unitil the current codes executes.
    

    try{
    
    //6.Dispatch Method
    //first i want to show the  loading , the loading when i want to show is, when the API is called , until the response get , these loading type is activated
     dispatch({type:FETCH_INIT})
    
    
    
    const response = await fetch("https://jsonplaceholder.typicode.com/users")

    

    const newData = await response.json() //response has recieved data from api, and here we converted the recieved data in to JSON format.

   //if the api response is success, then we defined the type : FETCH_START
   dispatch({type:FETCH_START, payload: newData}) //now in these payload variable, the data which we recieved from response is stored, 
    } catch (error){

   //now to show error case, we have to use try-catch, block
   //7.Error Handling 
            dispatch({type:FETCH_ERROR})
    }



    //Inside the API function call, the updated states through type we passed and performed actions
    //In next step we call these funcion, through API , we will get data or not lets see, Before, the recieved data to avoid repeated looping we have to import useEffect Hook, inside the useEffect() Hook, we will call the API function.
 }

   useEffect(()=> {
  // console.log(dataHandler())
  dataHandler()
   },[] //these [] dependency avoids repeated looping when data recieved
)

//so based on the loading,data,error, states, inside these component jsx file, we can the recieved data can be output on screen
    return (
        //<div>MultiState</div>
        <div>
            {state.loading && <p>Loading..</p>} {/*if loading is true then result will be displayed on screen i.e "Loading"*/}
            {/* if loading is true, then these <P> </P> statement will be displayed on screen*/} {/*These one we can achieve by using the short-circuit evaluation*/}
            {state.data && <div>
                {state.data.map(
                    (item) => {
                      return (
                        <div><h2>{item.name}</h2>
                            </div>
                      )
                    }
                )}
                </div>
                }
            {state.error && <div>{alert(state.error)}</div>}
        </div>
    )
}

//finally By using the useReducer() Hook, multiple states are managed and we can show the output.
export default MultiState