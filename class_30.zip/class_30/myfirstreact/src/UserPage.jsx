

import React from 'react'
import { useState, useEffect } from 'react'
const userDetails = "https://jsonplaceholder.typicode.com/posts"  //these api-link which holds dummy data in JSON object format
//these is an api now

//console.log('I am link from api',userDetails)




//1.create component
const UserPage = () => {

    //2.Get data with fetch method
    //By using the fetch method we have to display the data on screen, the data whcih we recieved from api-link, for that we have to create a useState with in the UserPage Component, and function by using async & await
    const [user, setUser] = useState([]) //Here i am passing 'empty array' for 'user' variable or state.
    
    //3.async/await
    //Here while creating function i am following async & await , because, we are getting the data from external resource , that external source data we are showing in project 
    //aync is a concept, that By asynchronous how our code execution is like , if our some parts of our code execution is delayed , then other codes apart from delayed codes shouls have to wait for how much time, and entire these process is will be in aync & await concept.
    const userHandler = async() => {  //function defined here in asynchronous format
         const response = await fetch(userDetails) //here we are passing the api link to fetch() method, what ever fetch method returns it will be stored in respone variable.
                         //Here we don't that how much time, fetch() method takes to get the data from api link, so for that purpose, we have to use 'await'
                         //These 'await' keyword does, until fetch() method perform on api-link completely, 'await' keyword  delays/prevents the execution of other codes
                         //'await' keyword ensures that ,after the completion of fetch() method, then only other codes will be executed.

         const newData = await response.json() //whatever the data i have recieved in 'response' variable, after the fetch() method applied on api-link, i want to store the rescieved data in 'response' in json format
         //By using these two steps our data fetching from backend api is completed
        

         //Lets assign the newData to user variable or state, which has the data recieved from backend api link, 
         //Here newData holds 100 json objects data, our 'user' variable already has an empty array in it.
         setUser(newData)


    }

   // console.log(userHandler()) //userHandler function is called/activated from here, which ensures to awiat fetch(), await response code, and set the 'user' state or variable with the newData which stores the fetched data from backend api link
      //these function activated, then enables propmises to undergo looping to avoid these we have to useEffect() hook
    //4.useEffect() hook
      useEffect(
        () => {
            console.log(userHandler())
        },[] //these empty array is dependency, which avoids the looping repeatedly.
        //whenever the changes happened in our component, that changes are detected by these dependency[], so when changes happens, at that time dependency renders the component on screen , & avoids infinit loop, whenever the changes happened to State or variable {i.e whenever we are using useState, and after arranging the value, if we use setState to manipulate the state, it may undergo loop to avoid these we have to use useEffect() hook}
    )   //when we fetch the data from api, avoids repeated rendering ensure only one time rendering on refreshing.we controlled the component by using dependency

    //Now fetched data is stored in user variable or state
   // console.log(user)

    return (

       //<div>UserPage</div>
       <div>
       {/*whatever the data we recieved from the fetch() method applying on backend api link, and stored in user state or variable, now we have to display that recieved data from api on screen by these jsx , for these we have to use Map method on user state which has array, then Map() will iterate over the array and take each object of array and passed to its arrow function parameter variable, and using that parameter variable we can access the object values (by using sntax parameter_variable.key_name*/}
       {/* 5.Map() method */}
       {user.map(
         (item) => {  //item variable travels on each user object while iterating , it stores each object on iteration, by using item variable which holds the object on respective iteration, we can use the item variable to display the object values.
            return (
                <div className="userSection">
                    <h2 style={{color: "blue"}}>{item.title}</h2>
                    <h3 style={{color: "green"}}>{item.body}</h3>
                    </div>
            )
         }
       )
       }
       </div>

    )
}

export default UserPage