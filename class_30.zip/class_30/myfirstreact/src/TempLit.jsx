

import React from 'react'

let Course = "React JS"
const TempLit = () => {
    return (
        <div>
            {`I am Learning ${Course}`} {/*Here these is Template Literal or Strings, we can write the strings using Template Literal concept and to pass the value with in Template Literal ,we have to use ${} , Template Literal format is we have to specify our string with in `backticks`, and to pass the value with in Template Literal we have to use ${variable_name} with in `backticks` */}
            <br/>
            I am Learning {Course}
            <h2>I am Learning {Course}</h2>
        </div>
    )
}

export default TempLit