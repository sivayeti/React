

import React, {useState} from 'react'


import Banner from '../components/Banner'
import Collections from '../components/Collections'
import Footer from '../components/Footer'
import Header from '../components/Header'

import WomenCollections from '../components/WomenCollections'

import {Gents} from '../data' //import the gents object data which is default exported there,importing gents object data from  'data.js'

import {Ladies} from '../data'

const MainPage = () => {


    //to check data is import or not
    console.log(Gents)

    //Lets define a useState Here
    const [gentsFashion, setGentsFashion] = useState(Gents);   //entire Gents object, which holds the each image path info, price info in key:value pair format like (image1 : "assets/image1.jps",price1: "559") , is stored in 'gentsFashion' state or variable
    //gentsFashion state or variable holds the each image path info,price info in object type.{key:value} pair format


    const [ladiesFashion, setLadiesFashion] = useState(Ladies);

    return (
        //<div>MainPage</div>
        //Now here we will import our all  components Header,Banner,Collectiosn,Footer
    <div>
        <Header />
        <Banner />
        <Collections gentsFashion = {gentsFashion} /> {/*By using "props" concept we are passing the gentsFashion variable which holds the each image path info in object format, while passing these data to child component 'Collections', we are giving a name 'gentsFashion' to passed data, then 'Collections' can access these by using that name getsFashion. */}
        <WomenCollections ladiesFashion = {ladiesFashion} />
        <Footer />
    </div>
    );
}

//we have to import the object data from data.js to here, and pass the data to child components by using props & props destrcuturing.
export default MainPage