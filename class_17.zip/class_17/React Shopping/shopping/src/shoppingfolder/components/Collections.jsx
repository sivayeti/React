

import React from 'react'

const Collections = (props) => {   //the data which is passed from MainPage component , is stored here () with in the parenthesis, to capture that we have to specify a variable 'props' here
         //Here props not only stores one property , it can able to stores n no.of properties, so, from Main component we are passing {gentsFashion} object data which holds the each image info, by giving name gentsFashion to these object data, here gentsFashion is one property, we can pass the n no.of properties from main component to child components, and we can store that n properties we use 'props' variable in () ,and to access each property we use syntax : props.prperty_name
   // console.log(props.gentsFashion);
    //Lets Destructure the Props, and stores the object values in variables which are same as keys.
    const {title, image1, image2, image3, image4, image5, image6} = props.gentsFashion
    //In these way we can fetch the data into variables from recieved object by using destructuring concept
    //And then the variables in destructuring,which holds the respective object values data , that variables can be used in our jsx code.

    return (
       // <div>Collections</div>
       <div className = 'collectionSection'>
           <h2>{title}</h2> {/* we should not pass the variable directly , we have to pass the variable with in the {curly braces}, to display the value which is hold by that variable, other wise 'Variable' is treated as plain text */}
           


            <div className="menImages">
                <img src = {image1} alt={title} />
                <img src = {image2} alt={title} />
                <img src = {image3} alt={title} />
                <img src = {image4} alt={title} />
                <img src = {image5} alt={title} />
                <img src = {image6} alt={title} />
            </div>

           
       </div>
    )
}

export default Collections