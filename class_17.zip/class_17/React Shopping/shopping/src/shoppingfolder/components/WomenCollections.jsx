
import React from 'react'

const WomenCollections = (props) => {

    const {title, image1, image2, image3, image4, image5, image6} = props.ladiesFashion
   
    return(
       // <div>WomenCollections </div>

       <div className = 'collectionSection'>
       <h2>{title}</h2> {/* we should not pass the variable directly , we have to pass the variable with in the {curly braces}, to display the value which is hold by that variable, other wise 'Variable' is treated as plain text */}
       {/*lets display another banner here in Collections component*/}
       <div className="bannerBox">
       <img src="assets/LadiesBanner.gif" alt="Ladies" ></img>
            </div>
      

        <div className="menImages">
            <img src = {image1} alt={title} />
            <img src = {image2} alt={title} />
            <img src = {image3} alt={title} />
            <img src = {image4} alt={title} />
            <img src = {image5} alt={title} />
            <img src = {image6} alt={title} />
        </div>

       
   </div>
    )
}

export default WomenCollections