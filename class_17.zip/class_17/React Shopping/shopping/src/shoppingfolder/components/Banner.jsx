


import React from 'react'

const Banner = () => {
    return (
        //<div>Banner</div>
        <div className='bannerSection' style={{ border: '3px solid red'}} >
            <div className="bannerBox">
                <img src="assets/GentsBanner.gif" alt="Banner" />
            </div>
        </div>
    )
}

export default Banner