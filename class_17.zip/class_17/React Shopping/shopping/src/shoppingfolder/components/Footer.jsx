

import React from 'react'

const Footer = () => {
    return (
        //<div>Footer</div>
        <div className="footerSection">
            <div className="bannerBox">
                <img src="assets/footer.png" alt="footer" />
            </div>
        </div>
    )
}

export default Footer