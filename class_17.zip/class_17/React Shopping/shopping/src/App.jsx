


import React from 'react'

import MainPage from './shoppingfolder/pages/MainPage'

import './App.css'

const App = () => {
  return (
    <div >
      {/*<h1>React Shopping</h1> */}

      <MainPage /> {/*whatever we rendered in MainPage (Header,Banner,Collections,Footer), MainPage holds all these components, so when we render the MainPage here in App.js, the components inside in the MainPage also displayed on screen*/}
      </div>

   
  )
}

export default App