
import React from 'react'

const SecondPage = () => {
    return (
      //  <div>SecondPage</div>
      <div>
        <h1>
            Second Component
        </h1>
      </div>
    )
}

export default SecondPage