
import React from 'react'

const FourthPage = () => {
    return (
       // <div>FourthPage</div>
       <div>
        <h1>
            Fourth Component
        </h1>
       </div>
    )
}

export default FourthPage