
import React from 'react'

const ThirdPage = () => {
    return (
      //  <div>ThirdPage</div>
      <div>
        <h1>
            Third Component
        </h1>
      </div>
    )
}

export default ThirdPage