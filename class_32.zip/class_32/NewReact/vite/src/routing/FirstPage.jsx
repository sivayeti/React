

import React from 'react'

const FirstPage = () => {
    return (
        <div><h1>First Component</h1></div>
    )
}

export default FirstPage