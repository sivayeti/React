

import React from 'react'
import{ Link } from 'react-router-dom'

const NavBar = () => {
    return (
        
        <div className = "navSection">
            
            <ul>
                <Link to="/abc">
                <li>FirstPage</li> {/*Now to these element which we apply the routing , for that element("FirstPage") should wrap with in  <Link> tags, and the Link tag takes ‘to’ attribute  assigned to the path value(/abc), which we specified in <Route path=”/abc” > tag to route that particular component{</FirstComponent/>}, which we want to display when user clicks on that element(FirstPage).*/}
                </Link>
                <Link to="/xyz">
                <li>SecondPage</li>
                </Link>
                <Link to="/apple">
                <li>ThirdPage</li>
                </Link>
                <Link to="/mango">
                <li>FourthPage</li>
                </Link>
            </ul>
        </div>
        
    )
}

export default NavBar