

import React from 'react'
import FirstPage from './routing/FirstPage'
import SecondPage from './routing/SecondPage'
import ThirdPage from './routing/ThirdPage'
import FourthPage from './routing/FourthPage'

import {Routes, Route } from 'react-router-dom'

import './App.css'
import NavBar from './Navbar'

const App = () => {
  return (
   
  // <div>App</div>
  <div>
  <NavBar/>
  <Routes>
    <Route path='/abc'   element = {<FirstPage />} />  {/*we have created a route here, that route tag takes path attribute, and with in the tag we can define the component, when user clicks on that path, then user redirected to the specified component. */}
    <Route path='/xyz' element = {<SecondPage /> } />
    <Route path='/apple' element = {<ThirdPage /> } />
    <Route path='/mango' element = {<FourthPage />} />

  </Routes>
   
   {/*
   <FirstPage />
   <SecondPage />
   <ThirdPage/>
   <FourthPage />
   */}
  </div>

  )
}

export default App