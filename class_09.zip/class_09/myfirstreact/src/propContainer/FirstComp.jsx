
/*
import React from 'react'

function FirstComp() {
    return (
        <div>FirstComp</div>
    )
}

export default FirstComp;
*/
//These is general Function, by using general Function we created the Componenet, by using the arrow functions also we can create the components



//To implement props, we have to create the components using rrow functions

import React from 'react'

const FirstComp = (props) => {   //the variable ‘props’ which we specified in (parenthesis) , can store n no.of properties send by Parent App to the child component, to access particular property we can specify ‘props.property_name’ eg: props.name;
    console.log(props)
    return (
       // <div>{name}</div> //we are using variables here with in {curly braces} ,because data will be passed from one component to other component
          <div>{props.name}</div>
    )
}

export default FirstComp