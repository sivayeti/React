

import React from 'react'

const SecondComp = (props) => {
    return (
        //<div>SecondComp</div>
        <div>{props.name}</div>
    )
}

export default SecondComp;