


import React from 'react'
import  './App.css';
import FirstComp from './propContainer/FirstComp'
import SecondComp from './propContainer/SecondComp';
import ThirdComp from './propContainer/ThirdComp';
import FourthComp from './propContainer/FourthComp';

const user = {
  name: "Shiavji",
  empire: "Maratha",
  country: "Akhanda Bharat"
}  //here we created a object it is like dictionary, lets pass the name in these dictionary to FirstComp
//Like in object format only we will get the data from API's. so we can pass the api information from Parent component to child component by {object_name.property_name} , eg: {user.name}, {user.empire}

function App() {
  return (
   <div className = "container"> {/*parent - element*/} {/*how we can identify the elements here, by using the Attributes like className,id we will give the name for each element*/}

      {/*<FirstComp name="Sivamani"/> */}  {/* we can pass the n no.of properties from here */}
      <FirstComp name={user.name} />
      <SecondComp name="Hara Hara"/>
      <ThirdComp name="Neelakanta"/>
      <FourthComp name="Mahadeva"/>

   </div> 

//App is the Parent component and FirstComp,SecondComp,ThirdComp,FourthComp, are the child components, 
//so here App component can pass the data to FirstComp,SecondComp,ThirdComp,FourthComp in single direction.
//To pass the property from Parent to child component the condition is in child component tag only Parent component can pass the data by assigning data to property variable.

//Props concept is used to pass the data from one component to other component i.e parent to child, it is one way communication from parent to child, child components can only read the data send by parent components, child components can't able to modify the recieve data, child components can only read the data.
  
  )
}

export default App;