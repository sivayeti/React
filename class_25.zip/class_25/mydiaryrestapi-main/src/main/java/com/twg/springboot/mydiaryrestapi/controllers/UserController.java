package com.twg.springboot.mydiaryrestapi.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.twg.springboot.mydiaryrestapi.entities.User;

import com.twg.springboot.mydiaryrestapi.service.UserService;

@RestController //here we are not retrieving the data in view format, we are retrieving the data in JSON format
@RequestMapping("/users") //giving the common url at class level instead of method level,the class level url , will be mapped with each end point in the code.

@CrossOrigin(origins = "http://localhost:3000")  //these ensures, that our api, should only executes the action, if request come these url only from frontend 
//these ensures that our backend api, should accepts request from frontend which runs on these port, and sends response based on the request.

public class UserController {

	@Autowired //
	private UserService userService; //By using the object of UserService class, we can access the crud methods in UserService class, but we should not create method directly, due to high coupling, the object should create and inject to this userService variable by spring container, to achieve these activity we have to use @Autowired annotation
	
	
	//write methods and bind with urls
	@GetMapping("/") //we are using http get method, and server understands that we have to perform GET (read) method, we will provide the same url for all actions , because, restapi is -resource oriented {entries,users -resources}
	public List<User> findAllUsers() //these function returns more than 1 user, then we have to use List<User> to store the returned entries,                {Here User is class, which is user defined data type , to hold differenet variables , and methods, (class which allows developers to develop  their desired data type, instead of using existed primitive datatype like int,string)}
	{
		List<User> userslist = userService.findAll();
		
		return userslist; //these automatically transformed into JSON/XML by jackson library 
	} //In spring web app, we will return the viewname, and model data to view Resolver by Controller
	//But in rest api, we should not return viewname, we have to return the model data{object} directly
	
	
	
	//Post mapping -insert operation
	@PostMapping("/")
	public User saveUser(@RequestBody User user)
	{
		User saveduser = userService.saveUser(user); //here id also generated while inserting these record
		return saveduser; //here returned saved user data is transformed into JSON by jackson
		
		//json to user object in function while posting carried by @RequestBody 
		//user object which returned is displayed in json when we view in postman , these carried by jackson
	}
	
	//Put Mapping -update operation
	@PutMapping("/")
	public User updateUser(@RequestBody User user)
	{
		//User updatedUser = userService.saveUser(user); //if we pass the json data, which now converted to User object, if we passed the json with id value, then save method in spring understands that , these user record is already existed, but i have to updated the existed values with current values{performs update operation}, if we not pass the json data with id, then save method performs insert operation
		
		User updatedUser = userService.updateUser(user);
		return updatedUser;
	}
	
	
	//Get Mapping - Read operation by ID
	@GetMapping("/{id}") //these url which activates the below method, the method purpose is to retrieve the user record based on the {id} which is passed along with  request url {id}
	//{id} these is called as 'path variable'
	//These path variable recieves the value from url, that path variable we have to assign to the paramater 'long id' in getUser() function  by using '@PathVariable("id")' annotation
	//{@PathVariable("id") long id} specifies that the variable id which recieves the value from url , is should be assigned to 'long id'
	public User getUser(@PathVariable("id") long id)//the {id} in url is passed to the function here. based on these id, and passing these {id} into findById() function we are retrieving the User record of that particular {id}
	{
		User user = userService.findById(id); 
		return user; //the returned user type object is transformed into json format by 'jackson' library.
	}
	
	
	
	
	//Delete Mapping - Delete operation by ID
	@DeleteMapping("/{id}")
	public void deleteUser(@PathVariable("id") long id)
	{
		User user = userService.findById(id); //based on the delete url request we will get user {id}, which we want to delete, and by using id, we will fetch user record by using 'findById()' function, and by using passing retrieved entry record into deleteUser() function, we will perform the delete operation on that user record
		userService.deleteUser(user);
	}
	
	

	
	//Update Mapping - Update operation by ID
	//the above update method can be done based on the {id} in json body.
	//But these update method, ignores the {id} in json body,performs update operation based on the {id} recieved from the url.
	@PutMapping("/{id}")
	//public User updateUser1(@PathVariable("id") long id) //not only path variable, here we also want the @request json body from put url in postman
	public User updateEntry1(@PathVariable("id") long id, @RequestBody User user)
	{
		
		//user is having the data which we want to update on entry1 
		User user1 = userService.findById(id); //user1 is from db
		//user is having the data which we want to update on user1 
		//user1 values should update with user object values
		
		
		//these way if we are passing the entire body , and not passing other cols as null values
		user1.setUsername(user.getUsername());
		user1.setPassword(user.getPassword());
		
		User updatedUser = userService.updateUser(user1); //now we are performing update operation on table , by using updated user1 details with user object details.
		
		return updatedUser;
		
		
		
		//these way id we are passing only updated detail, and passing other cols as null values, (Note - these way can be only used when cols doesnot has the 'Not null' property, other wise PUT endpoint throws an error)
		/*
		String username = user.getUsername(); 
		String password = user.getPassword();
		
		
		//json body can send any of the above values, leaves any others, so accordig to these we have to develop code, if json body sent which are transformed to User user, and we will check in user variables, if they are empty we should no need to set that empty values, we will leave that should be existed values, if the user variables are not null and having values, then  we have to set that values to the user record
		
		if(username!=null && username.length() > 0)
		{
			user1.setUsername(user.getUsername());
		}
		if(password!=null)
		{
			user1.setPassword(user.getPassword());
		}
		
		//user1.setUsername(user.getUsername());
		//user1.setPassword(user.getPassword());
		
		
		User updatedUser = userService.updateUser(user1); //now we are performing update operation on table , by using updated user1 details with user object details.
		
		return updatedUser;
		*/
	}
	
	
	
	
	@PatchMapping("/{id}")
	public User updateUser2(@PathVariable("id") long id, @RequestBody User user)
	{
		//In patch method, @RequestBody assigns username passed via json body is mapped to username Variable in User class object, and leaves remain other as empty
		
		//user object is having the data which we want to update on user1 
		User user1 = userService.findById(id); //user1 is from db
		//user is having the data which we want to update on user1 
		//user1 values should update with user object values except user object variables which are holding null values
		
		String username = user.getUsername(); 
		String password = user.getPassword();
		
		
		//json body can send any of the above values, leaves any others, so accordig to these we have to develop code, if json body sent which are transformed to User user, and we will check in user variables, if they are empty we should no need to set that empty values, we will leave that should be existed values, if the user variables are not null and having values, then  we have to set that values to the user record
		
		if(username!=null && username.length() > 0)
		{
			user1.setUsername(user.getUsername());
		}
		if(password!=null)
		{
			user1.setPassword(user.getPassword());
		}
		
		//user1.setUsername(user.getUsername());
		//user1.setPassword(user.getPassword());
		
		
		User updatedUser = userService.updateUser(user1); //now we are performing update operation on table , by using updated user1 details with user object details.
		
		return updatedUser;
	}
	
	
}



//we have perform all crud operations on our resource "users"