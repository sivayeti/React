package com.twg.springboot.mydiaryrestapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.twg.springboot.mydiaryrestapi.entities.Entry;
import com.twg.springboot.mydiaryrestapi.repository.EntryRepository;

@Service
public class EntryServiceImpl implements EntryService {

	@Autowired
	private EntryRepository entryRepository;
	
	public EntryRepository getEntryRepository() {
		return entryRepository;
	}

	public void setEntryRepository(EntryRepository entryRepository) {
		this.entryRepository = entryRepository;
	}

	
	@Override
	public Entry saveEntry(Entry entry) {
		// TODO Auto-generated method stub
		return entryRepository.save(entry);
	}

	@Override
	public Entry updateEntry(Entry entry) {
		// TODO Auto-generated method stub
		return entryRepository.save(entry);
	}

	@Override
	public void deleteEntry(Entry entry) {
		// TODO Auto-generated method stub

		entryRepository.delete(entry);
	}

	@Override
	public Entry findById(Long id) {
		// TODO Auto-generated method stub
		return entryRepository.findById(id).get();
	}

	@Override
	public List<Entry> findAll() {
		// TODO Auto-generated method stub
		return entryRepository.findAll();
	}

	
	//Above all methods are default provided by JPA repository in EntryRepository interface
	//Below method , body we have to specify in EntryRepository interface, then jpa will makes that method, for any customization queries, we have to specify by using '@Query' annotation 
	@Override
	public List<Entry> findByUserid(long id) {
		// TODO Auto-generated method stub
		return entryRepository.findByUserid(id);
	}

}
