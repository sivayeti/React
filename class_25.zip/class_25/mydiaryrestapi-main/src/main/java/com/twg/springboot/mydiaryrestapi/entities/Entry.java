package com.twg.springboot.mydiaryrestapi.entities;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity //to specify spring that these entity should map with tables in database
@Table(name="entries") //to specify the table name  that these entity should match, with the table in database
public class Entry {

	@Id //These specifies the spring that these column is unique primary key
	@GeneratedValue(strategy =  GenerationType.IDENTITY) //These is for auto incrementation
	private long id;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd") //we have to specify in which format data have to store in database
	private Date entrydate;
	
	private String description;
	
	private long userid;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Date getEntrydate() {
		return entrydate;
	}

	public void setEntrydate(Date entrydate) {
		this.entrydate = entrydate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public long getUserid() {
		return userid;
	}

	public void setUserid(long userid) {
		this.userid = userid;
	}
}
