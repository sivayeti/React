package com.twg.springboot.mydiaryrestapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.twg.springboot.mydiaryrestapi.entities.User;
import com.twg.springboot.mydiaryrestapi.repository.UserRepository;



@Service //we have to specify the spring that these is the service layer
public class UserServiceImpl implements UserService {

	@Autowired //spring container understood that these is a class in other place in these project , but it is a property here and we have to create a object for these class from outtside, and inject that object to here these property during run time, and enables from these current class using that property or object , we can access the functions in UserRepository Interface.
	UserRepository userRepository;
	
	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
		
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	@Override
	public void deleteUser(User user) {
		// TODO Auto-generated method stub
        userRepository.delete(user);
	}

	@Override
	public User findById(Long id) {
		// TODO Auto-generated method stub
		//return userRepository.findById(id);  //these will returns the data in optional type
		//we will use get() method to convert optional to User datatype
		return userRepository.findById(id).get();
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User findByUsername(String username) {
		// TODO Auto-generated method stub
		return userRepository.findByUsername(username);
	}

	

}
