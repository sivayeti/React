package com.twg.springboot.mydiaryrestapi.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.twg.springboot.mydiaryrestapi.entities.Entry;
import com.twg.springboot.mydiaryrestapi.service.EntryService;

@RestController //here we are not retrieving the data in view format, we are retrieving the data in JSON format
public class EntryController {

	@Autowired //
	private EntryService entryService; //By using the object of EntryService class, we can access the crud methods in EntryService class, but we should not create method directly, due to high coupling, the object should create and inject to this entryService variable by spring container, to achieve these activity we have to use @Autowired annotation
	
	
	//write methods and bind with urls
	@GetMapping("/entries/") //we are using http get method, and server understands that we have to perform GET (read) method, we will provide the same url for all actions , because, restapi is -resource oriented {entries,users -resources}
	public List<Entry> findAllEntries() //these function returns more than 1 entry, then we have to List<Entry> to store the returned entries
	{
		List<Entry> entrieslist = entryService.findAll();
		
		return entrieslist; //these automatically transformed into JSON/XML by jackson library 
	} //In spring web app, we will return the viewname, and model data to view Resolver by Controller
	//But in rest api, we should not return viewname, we have to return the model data{object} directly
	
	
	
	//Post mapping -insert operation
	@PostMapping("/entries/")
	public Entry saveEntryEntry(@RequestBody Entry entry)
	{
		Entry savedentry = entryService.saveEntry(entry); //here id also generated while inserting these record
		return savedentry; //here returned saved entry data is transformed into JSON by jackson
		
		//json to entry object in function while posting carried by @RequestBody 
		//entry object which returned is displayed in json when we view in postman , these carried by jackson
	}
	
	//Put Mapping -update operation
	@PutMapping("/entries/")
	public Entry updateEntry(@RequestBody Entry entry)
	{
		//Entry updatedEntry = entryService.saveEntry(entry); //if we pass the json data, which now converted to Entry object, if we passed the json with id value, then save method in spring understands that , these entry record is already existed, but i have to updated the existed values with current values{performs update operation}, if we not pass the json data with id, then save method performs insert operation
		
		Entry updatedEntry = entryService.updateEntry(entry);
		return updatedEntry;
	}
	
	
	//Get Mapping - Read operation by ID
	@GetMapping("/entries/{id}") //these url which activates the below method, the method purpose is to retrieve the entry record based on the {id} which is passed along with  request url {id}
	//{id} these is called as 'path variable'
	//These path variable recieves the value from url, that path variable we have to assign to the paramater 'long id' in getEntry() function  by using '@PathVariable("id")' annotation
	//{@PathVariable("id") long id} specifies that the variable id which recieves the value from url , is should be assigned to 'long id'
	public Entry getEntry(@PathVariable("id") long id)//the {id} in url is passed to the function here. based on these id, and passing these {id} into findById() function we are retrieving the entry record of that particular {id}
	{
		Entry entry = entryService.findById(id); 
		return entry; //the returnred entry type object is transformed into json format by 'jackson' library.
	}
	
	
	
	
	//Delete Mapping - Delete operation by ID
	@DeleteMapping("/entries/{id}")
	public void deleteEntry(@PathVariable("id") long id)
	{
		Entry entry = entryService.findById(id); //based on the delete url request we will get entry {id}, which we want to delete, and by using id, we will fetch entry record by using 'findById()' function, and by using passing retrieved entry record into deleteEntry() function, we will perform the delete operation on that entry record
		entryService.deleteEntry(entry);
	}
	
	
	
	
	//Update Mapping - Update operation by ID
	//the above update method can be done based on the {id} in json body.
	//But these update method, ignores the {id} in json body,performs update operation based on the {id} recieved from the url.
	@PutMapping("entries/{id}")
	//public Entry updateEntry1(@PathVariable("id") long id) //not only path variable, here we also want the @request json body from put url in postman
	public Entry updateEntry1(@PathVariable("id") long id, @RequestBody Entry entry)
	{
		
		//entry is having the data which we want to update on entry1 
		Entry entry1 = entryService.findById(id); //entry1 is from db
		//entry is having the data which we want to update on entry1 
		//entry1 values should update with entry values
		
		
		entry1.setDescription(entry.getDescription());
		entry1.setEntrydate(entry.getEntrydate());
		entry1.setUserid(entry.getUserid());
		
		Entry updatedEntry = entryService.updateEntry(entry1); //now we are performing update operation on table , by using updated entry1 details with entry details.
		
		return updatedEntry;
	}
	
	
	
	
	@PatchMapping("/entries/{id}")
	public Entry updateEntry2(@PathVariable("id") long id, @RequestBody Entry entry)
	{
		//In patch method, @RequestBody assigns userid passed via json body is mapped to userid Variable in Entry class object, and leaves remain other as empty
		
		//entry is having the data which we want to update on entry1 
		Entry entry1 = entryService.findById(id); //entry1 is from db
		//entry is having the data which we want to update on entry1 
		//entry1 values should update with entry values
		
		String desc = entry.getDescription(); 
		Date dt = entry.getEntrydate();
		long usrid = entry.getUserid();
		
		//json body can send ny of the above values, leaves any others, so accordig to these we have to develop code, if json body sent which are transformed to Entry entry, and we will check in entry variables, if they are empty we should no need to set that empty values, we will leave that should be existed values, if the entry variables are not null and having values, then we have the we have to set that values to the entry record
		
		if(desc!=null && desc.length() > 0)
		{
			entry1.setDescription(entry.getDescription());
		}
		if(dt!=null)
		{
			entry1.setEntrydate(entry.getEntrydate());
		}
		if(usrid>0) //if we don't pass any value in json body for userid, by default entry variable userid takes its values as 0, ,if we pass the usrid in json, then that should be greater than 0 value only we pass, we have to check here usrid>0 , then we need to update entry.userid with usrid, 
		{
			entry1.setUserid(entry.getUserid());
		}
		//entry1.setDescription(entry.getDescription());
		//entry1.setEntrydate(entry.getEntrydate());
		//entry1.setUserid(entry.getUserid());
		
		Entry updatedEntry = entryService.updateEntry(entry1); //now we are performing update operation on table , by using updated entry1 details with entry details.
		
		return updatedEntry;
	}
	
	
}



//we have perform all crud operations on our resource "entries"