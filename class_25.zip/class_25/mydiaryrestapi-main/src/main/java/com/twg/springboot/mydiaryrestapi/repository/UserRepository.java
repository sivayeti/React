package com.twg.springboot.mydiaryrestapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.twg.springboot.mydiaryrestapi.entities.User;

public interface UserRepository extends JpaRepository<User, Long> {

	//public User findByUsername(String username); //Actually the UserRepository which is sub class for JPA repository, can have the crud operations based on user id, any other functionality or operation we only have to define the repository DAO layer,, we defined the findByUsername() function in these repository interface dao, now where we have to implement these function body ?//Spring boot provides the feature that is , if we define the function, then according to that spring only writes the function in JPA or User Repository 
	   //select * from users where username = "";
		
		// public User findByPassword(String password);
		//select * from password where password="";

		//Eg: for cutsomized queries, select * from employee where age > 30;
		//if i want a retrieve a data in combination like, select * from users  where username = "" & password = "";
	    //to handle these we have to use "@Query" annotation and we will specify our customized queries, based on our inputs then we will define our function
		
		//@Query(value = "select * from users where username=:username LIMIT 1", nativeQuery = true) //By using native query attribute we are specifying that these is not java related query, it is sql query
		public User findByUsername(String username); //to pass these parameter username into our query we will use named parameters(:username)
		//for these normal queries we have to specify by findBycolName(id) , spring automatically prepares query, if any customized queries then we have to use "@Query"
}
