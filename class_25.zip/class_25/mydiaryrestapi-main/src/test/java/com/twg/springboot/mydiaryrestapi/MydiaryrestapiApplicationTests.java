package com.twg.springboot.mydiaryrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MydiaryrestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
