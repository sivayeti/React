


import React from 'react'

function TestComp() {
    return (
        <div style={{ border: '2px solid yellow' , margin: '25px' }}>TestComp
            <h2 style={{ border: '2px solid violet',margin: '10px'  }}>Some Code</h2>
            <p style={{ border: '2px solid pink',margin: '10px'  }}>This is test</p>
        </div>
    )
}

export default TestComp;