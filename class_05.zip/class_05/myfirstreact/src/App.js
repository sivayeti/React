import logo from './logo.svg';
import './App.css';


import Apple from './Apple'
import Sample from './example/Sample';

import './sample.css' //so whatever the styles we written in 'sample.css', thos styles are applied on here.

function App() {
  return (
    <div className="App">

     <Apple/> {/*Here Apple component also has <h1> tag</h1> ,on these tag also  ,whatever the css we written is applied on it, and sample.css is override, that <h1> tag inline css too*/}

     <Sample />

     <h1 style={{ border: '2px solid grey',margin: '25px'  }}> This is sample CSS File</h1>
    </div>
  );
}

export default App;

//we have to create a tag for our Apple component inside the App Component
//In these way can create the component, and display the content(text,images,layouts,e.tc) on screen by using components