//jsx is a extension

//Lets develop the component here.

//1.we created a file Apple

function Apple(){ //2.we created a function Apple in that we returned a h1 tag with text 'Hello World'
    return(
        <h1 style={{ border: '2px solid red' }}>Hello World</h1>
    )
}

export default Apple; //3.we export the created function here
//The exported function here, should have to import in Main Component 'App.js'


//By continuing these process, lets we create the nested component.


//In above we created function, same as our file name, and we exported the created function, to simplify these process we have an extension 'Simple React Snippet.These snippet gereate the snippet code for component.




//Note:
//Component can be responsible for returning or show the h1,h2,div,p,images,a link, any content content on screen, these content we displayed on the screen by using Components , because when we create group of components and each component displays respective content and then we can apply the styling on the components, and another advantage is we can make our interface portable based on screen device.
//When we displayed the content by using components, we can easily change the User interface based on the desktop, mobile(portable), we can achieve portability when we developed the interface by using components
