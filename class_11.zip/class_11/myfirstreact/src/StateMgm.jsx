

import React from 'react'

import {useState} from 'react' //syntax to import the useState from react.




const StateMgm = () => {

    //Syntax to use , useState Hook.
    const[city, setCity] = useState("Hyderabad") //these "Hyderabad" value is assigned to 'city' state or variable.
    //city is our state (means variable), 'setCity' is used to maipulate or change the city(state) variable value.

    console.log(city)

    setCity("Delhi") //By using setCity(setState) we are manipulating the state or variable value.

    console.log(city)
    return (
        <div>StateMgm</div>
    )
}

export default StateMgm