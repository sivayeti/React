
import React from 'react'

const FourthComp = (props) => {
    return (
        //<div>FourthComp</div>
        <div>{props.name}</div>
    )
}
export default FourthComp