


import React from 'react'
import  './App.css';
import FirstComp from './propContainer/FirstComp'
import SecondComp from './propContainer/SecondComp';
import ThirdComp from './propContainer/ThirdComp';
import FourthComp from './propContainer/FourthComp';

const myCar = {
  model: "Maruthi",
  year: 2022,
  dealer: "Nixon",
  color: "red"
}

function App() {
  return (
   <div className = "container"> 
       
       <SecondComp myCar = {myCar}/>
      
   </div> 
 
  )
}

export default App;