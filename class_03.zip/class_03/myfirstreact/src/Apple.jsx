//jsx is a extension

//Lets develop the component here.

//1.we created a file Apple

function Apple(){ //2.we created a function Apple in that we returned a h1 tag with text 'Hello World'
    return(
        <h1>Hello World</h1>
    )
}

export default Apple; //3.we export the created function here
//The exported function here, should have to import in Main Component 'App.js'