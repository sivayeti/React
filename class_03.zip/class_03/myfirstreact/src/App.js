import logo from './logo.svg';
import './App.css';


import Apple from './Apple'

function App() {
  return (
    <div className="App">

     <Apple/>
    </div>
  );
}

export default App;

//we have to create a tag for our Apple component inside the App Component
//In these way can create the component, and display the content(text,images,layouts,e.tc) on screen by using components