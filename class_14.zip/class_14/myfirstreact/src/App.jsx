


import React from 'react';
import { useState } from 'react';

import FirstComp from './propContainer/FirstComp';
import  './App.css';



const App = () => {

  const [sampleCondition, setSampleCondition] = useState(true) //here sampleCondition state or variable holds the value true which is boolean value.

  //Ternary Condition, It is short hand notation of 'if/else' statements, and ':' seperates the 'true condition' on its left side, and 'false condition' on its right side.
  //Ternary statement syntax: 
  //sampleCondition?"This is True Statement" : "I am False Statement"

  return (
   <div > 
       <h1>Welcome to React</h1>
       <br/>
       {/*<h1>{sampleCondition?"This is True Statement" : "I am False Statement"} </h1>*/}

       {/*Now i want to render(means display on screen) FirstComp, if sampleCondition holds true value, otherwise i want to render the "I am False Statemnt" */}
       {sampleCondition ? <FirstComp /> : "I am False Statement"} {/*we have to pass the variables or states which holds the values, with in the div tag as specified with in the brackets {} */}
   </div> 
 
  );
};

export default App;