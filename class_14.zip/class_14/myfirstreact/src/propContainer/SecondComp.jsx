

import React from 'react'

const SecondComp = (props) => {

    //Props Destructuring Syntax
    const {model, year, dealer, color} = props.myCar;
    //the variables should be same as keys in passed object

    return (
        //<div>SecondComp</div>
        //<div>{props.name}</div>
        <div> {/*Parent Element*/}
            <div>{model}</div>   {/*Child Element*/}
            <div>{year}</div>
            <div>{dealer}</div>
            <div>{color}</div>
        </div>
    )
}

export default SecondComp;