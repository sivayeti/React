import React, { useState } from "react";


//import the react-toastify feature

import { ToastContainer, toast } from 'react-toastify';
//import 'react-toastify/dist/ReactToastify.css';

const FormExample = () => {

  const [userName, setUserName] = useState("");

  const [newUserDetails, setNewUserDetails] = useState();


  //const notify = () => toast("Wow so easy!");

  const notify = () => toast("Your data is uploaded successfully!");

  const getUserName = (event) => {
    setUserName(event.target.value);
  };

  const userDetails = (e) => {
    e.preventDefault();
    setNewUserDetails(userName);
    notify()
  };

  return (
    <section className="formSection">
      <h2>Hello,{newUserDetails}</h2>
      <ToastContainer />
      <div className="inputDiv">
      
        <form onSubmit={userDetails}>
        
          <input
            type="text"
            placeholder="Enter your Name"
            onChange={getUserName}
          />
          <br />
          <button className="submitBtn" type="submit">
            Submit
          </button>
        </form>
        
      </div>

    </section>
  );
};

export default FormExample;
