

import React from 'react'

let sampleArray = ["Apple","Mango", 35, {userName: "Siva"}]
                 // 0,      1,       2,   3    //indexes for array
//These array stores group of values in it.
//we have to fetch the values in react

const SampleArray = () => {
    return (

        <div>
            {sampleArray[1]}

            <h2>{sampleArray[0]} is red in color</h2>
           
           <h2>My age is {sampleArray[2]}</h2>

           <h2>My name is {sampleArray[3]}</h2>
            </div>
    )
}

export default SampleArray