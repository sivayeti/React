

import React, {useState} from 'react'



const Employee = () => {


    //2.Get Form Data
  //create the states as same as column names in user table in database
  const[username, setUsername] = useState("") 
  const[password, setPassword] = useState("")
  //Now we have to trigger the changes in form and that changes we have to set to our states, for that , we have to use onChange() event , to capture the each change and store in one variable, by using syntax e.target.value, then onSubmit() after entering the text , these event calls a function that function should set the input data to states.


  //console.log(username,password) //these enables to diplay the values , while typing , these can be done by using onChange() event

  const empDetails = {username,password} //creating an object here, already username,password states or variables holding values, i.e we already predefined the values for keys username, password, so if we place the variable holding values or key in {curly braces} , then it is an object, we named that object as 'empDetails'
 
  const empHandler =async(e) => {   //these funcion executes and displays only when 'submit' button is clicked
     //while submit the form , it has a behaviour to refresh the page, to avoid that activity we use e.preventDefault() in-Built function.
     e.preventDefault();
     console.log(empDetails)

     //3.Form Data to Database
     //As of now we are done with Get Form Data, then we have to send the Data to backend API , by POST method (to perform insert operation with these data)
    
     //for that we will create a variable and add fetch() method, for that fetch() method , we have to pass the api-link

     //const response =await fetch("http://localhost:8080/mydiaryapi/users/") //In next level we have to make these function 'empHandler' asynchronous, because we are sending the data to api which is  external source ,we don't know how much time it take to perform POST operation, so thats why we are making these function as asynchronous.
     
     //until these activity is done, it doesn't allow other codes to execute //to use 'await' we have to make the function asynchronous first by using 'async' keyword.
     //In next step we have send an object along with api link by adding the method(which method we want to perform GET,POST) and header and body(values which we are sending from our frontend code in JSON format)
    









     /*try catch block */


    try{  //if the response is request is done, and reponse recieved successfully, then it will be in try block only, if request is not done, and response recieved as error, then it will fall to catch block

      
     const response =await fetch("http://localhost:8080/mydiaryapi/user/", {method:"POST", headers: {"Content-Type": "Application/json"}, body:JSON.stringify(empDetails)}) 
     alert("Data posted successfully")
    }catch(error){
      console.log(error)
      alert("Sorry Data Failed to post")
    }
     //const response =await fetch("http://localhost:8080/mydiaryapi/users/", {method:"POST", headers: {"Content-Type": "Application/json"}, body:JSON.stringify(empDetails)}) 
                                                                                          //here headers is standard object value, which is specifying by backend developer


  }


    return (
        //1.Form Creation
        <div className="empForm">
             <form onSubmit={empHandler}>
                <label>Employee Name </label> <br/>
                <input type="text" name='username' onChange={(e)=> setUsername(e.target.value)}></input> <br/>
                
                <label>Employee Password </label> <br/>
                <input type="text"  name='password' onChange={(e)=>setPassword(e.target.value)}></input>  <br/>
                <button type='submit'>Submit</button> {/*when user clicks on these submit button, then it triggers the onSubmit() event in form tag and activates the respective function. */}
             </form>
        </div>
    )
}

export default Employee