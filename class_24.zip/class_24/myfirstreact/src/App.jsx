


import React from 'react';


import Resize from './Chat.jsx'
import  './App.css';
import FormExample from './FormExample.jsx';
import SampleArray from './SampleArray.jsx';
import TempLit from './TempLit.jsx';
import UserPage from './UserPage.jsx';




const App = () => {

  return (
   <div className='container'> 
       <h1>Welcome to React

        {/*<Resize />*/}
        </h1>

        {/*<FormExample /> */}
        {/*<SampleArray /> */}

        {/*<TempLit /> */}

        <UserPage />
   </div> 
 
  );
};

export default App;